import hashlib
import hmac
import json
import sqlite3

import pytest

from itamx.app import create_app

SECRET = "test-secret"


@pytest.fixture()
def env(tmp_path):
    app = create_app({"DB": str(tmp_path / "t.db"), "ADMIN_PASSWORD": "Admin#12345", "WEBHOOK_SECRET": SECRET})
    c = app.test_client()
    tok = c.post("/api/v1/auth/login", json={"username": "admin", "password": "Admin#12345"}).get_json()["token"]
    H = {"Authorization": "Bearer " + tok}

    def call(method, path, data=None, headers=None, raw=None):
        h = dict(H if headers is None else headers)
        kw = {"headers": h}
        if raw is not None:
            kw["data"] = raw
        elif data is not None:
            kw["json"] = data
        return getattr(c, method)("/api/v1" + path, **kw)

    def user(name, role, dept="研发部", emp=None):
        r = call("post", "/users", {"username": name, "password": "Passw0rd!!", "role": role, "department": dept,
                                    "emp_no": emp or name.upper(), "full_name": name})
        assert r.status_code == 201, r.get_json()

    def login(name):
        t = c.post("/api/v1/auth/login", json={"username": name, "password": "Passw0rd!!"}).get_json()["token"]
        return {"Authorization": "Bearer " + t}

    return app, call, user, login, str(tmp_path / "t.db")


def sign(raw):
    return {"X-Signature": "sha256=" + hmac.new(SECRET.encode(), raw, hashlib.sha256).hexdigest(), "Content-Type": "application/json"}


def new_asset(call, **kw):
    d = dict(name="ThinkPad T14", category="LT", serial_number="PF4X1", purchase_price=8680, purchase_date="2026-03-12",
             location="总部-IT仓库", auto_stock=True)
    d.update(kw)
    r = call("post", "/assets", d)
    assert r.status_code == 201, r.get_json()
    return r.get_json()


def test_asset_lifecycle_and_timeline(env):
    app, call, user, login, _ = env
    user("zhangsan", "EMPLOYEE", emp="EMP00128")
    a = new_asset(call)
    assert a["asset_code"].startswith("IT-LT-2026-") and a["status"] == "IN_STOCK"
    r = call("post", f"/assets/{a['asset_code']}/actions/issue", {"user": "EMP00128", "accessories": ["电源", "鼠标"], "location": "总部-2F研发区"})
    assert r.status_code == 200 and r.get_json()["to"] == "IN_USE"
    d = call("get", f"/assets/{a['asset_code']}").get_json()
    assert d["holder_name"] == "zhangsan" and d["department_name"] == "研发部"
    types = [e["event_type"] for e in d["timeline"]]
    assert types == ["ASSET_CREATED", "ASSET_PURCHASED", "ASSET_RECEIVED", "ASSET_INSPECTED", "ASSET_STOCKED_IN", "ASSET_ISSUED"]


def test_cannot_set_status_directly_or_skip_states(env):
    _, call, *_ = env
    a = new_asset(call, auto_stock=False)
    assert call("patch", f"/assets/{a['id']}", {"status": "SCRAPPED"}).status_code == 400
    assert call("post", f"/assets/{a['id']}/actions/scrap", {}).status_code == 409      # DRAFT -> SCRAPPED not allowed
    assert call("post", f"/assets/{a['id']}/actions/issue", {"user": "admin"}).status_code == 409
    assert call("get", f"/assets/{a['id']}").get_json()["status"] == "DRAFT"


def test_duplicate_serial_rejected(env):
    _, call, *_ = env
    new_asset(call)
    assert call("post", "/assets", dict(name="x", category="LT", serial_number="PF4X1")).status_code == 409


def test_scrap_requires_four_eyes(env):
    _, call, user, login, _ = env
    user("it1", "IT_ADMIN", "IT部")
    a = new_asset(call)
    assert call("post", f"/assets/{a['id']}/actions/retire_request", {"reason": "老化"}).status_code == 200
    # admin (SUPER_ADMIN) requested; another admin approves
    h = login("it1")
    assert call("post", f"/assets/{a['id']}/actions/scrap", {}, headers=h).status_code == 200
    assert call("get", f"/assets/{a['id']}").get_json()["status"] == "SCRAPPED"
    assert call("post", f"/assets/{a['id']}/actions/dispose", {"method": "回收"}, headers=h).status_code == 200
    # requester == approver blocked for non-super roles
    user("it2", "IT_ADMIN", "IT部")
    b = new_asset(call, serial_number="PF4X2")
    h2 = login("it2")
    assert call("post", f"/assets/{b['id']}/actions/retire_request", {"reason": "x"}, headers=h2).status_code == 200
    assert call("post", f"/assets/{b['id']}/actions/scrap", {}, headers=h2).status_code == 403


def test_repair_roundtrip_webhook_idempotent_and_signed(env):
    app, call, user, login, _ = env
    user("zhangsan", "EMPLOYEE", emp="EMP00128")
    a = new_asset(call)
    call("post", f"/assets/{a['id']}/actions/issue", {"user": "EMP00128"})
    zs = login("zhangsan")
    r = call("post", f"/assets/{a['id']}/actions/repair_request", {"fault": "无法开机"}, headers=zs)
    assert r.status_code == 200, r.get_json()
    local = r.get_json()["ref_no"]
    assert call("get", f"/assets/{a['id']}").get_json()["status"] == "REPAIR"

    body = {"eventId": "evt-1", "event": "REPAIR_COMPLETED", "localRepairNo": local, "repairId": "R202611250031",
            "result": "已更换主板", "cost": 680.0, "completedAt": "2026-11-25T16:20:00"}
    raw = json.dumps(body).encode()
    # bad signature
    assert app.test_client().post("/api/v1/webhooks/repair-events", data=raw, headers={"X-Signature": "sha256=bad", "Content-Type": "application/json"}).status_code == 401
    c = app.test_client()
    assert c.post("/api/v1/webhooks/repair-events", data=raw, headers=sign(raw)).get_json()["status"] == "processed"
    # replay + same repair with a NEW event id: still no duplicate state change
    assert c.post("/api/v1/webhooks/repair-events", data=raw, headers=sign(raw)).get_json()["status"] == "duplicate_ignored"
    body2 = dict(body, eventId="evt-2")
    raw2 = json.dumps(body2).encode()
    assert c.post("/api/v1/webhooks/repair-events", data=raw2, headers=sign(raw2)).get_json()["note"] == "repair already closed"

    d = call("get", f"/assets/{a['id']}").get_json()
    assert d["status"] == "READY_FOR_USE" and d["repair_cost_total"] == 680.0 and d["tco"] == 8680 + 680
    assert [e["event_type"] for e in d["timeline"]].count("REPAIR_COMPLETED") == 1
    assert len(d["repairs"]) == 1 and d["repairs"][0]["remote_repair_id"] == "R202611250031"
    # redeliver to the original holder
    assert call("post", f"/assets/{a['id']}/actions/issue", {}).get_json()["to"] == "IN_USE"


def test_employee_can_only_act_on_own_assets(env):
    _, call, user, login, _ = env
    user("zs", "EMPLOYEE", emp="E1")
    user("ls", "EMPLOYEE", emp="E2")
    a = new_asset(call)
    call("post", f"/assets/{a['id']}/actions/issue", {"user": "E1"})
    ls = login("ls")
    assert call("get", f"/assets/{a['id']}", headers=ls).status_code == 403
    assert call("post", f"/assets/{a['id']}/actions/repair_request", {"fault": "x"}, headers=ls).status_code == 403
    assert call("get", "/assets", headers=ls).get_json() == []
    assert call("post", "/assets", dict(name="x", category="LT"), headers=ls).status_code == 403


def test_auditor_is_read_only(env):
    _, call, user, login, _ = env
    user("aud", "AUDITOR", "IT部")
    a = new_asset(call)
    h = login("aud")
    assert call("get", f"/assets/{a['id']}", headers=h).status_code == 200
    assert call("get", "/audit-logs", headers=h).status_code == 200
    assert call("post", f"/assets/{a['id']}/actions/loan", {"user": "aud"}, headers=h).status_code in (403,)


def test_consumable_ledger_batches_lock_and_trace(env):
    _, call, user, login, path = env
    user("zs", "EMPLOYEE", emp="E1")
    user("ls", "EMPLOYEE", emp="E2")
    cid = call("post", "/consumables", {"code": "MS-01", "name": "鼠标", "safety_stock": 10}).get_json()["id"]
    r1 = call("post", "/inventory/receive", {"consumable": "MS-01", "warehouse": "IT仓库A", "quantity": 100, "batch_no": "B1"})
    assert r1.status_code == 200
    call("post", "/inventory/receive", {"consumable": "MS-01", "warehouse": "IT仓库A", "quantity": 20, "batch_no": "B2"})
    assert call("post", "/inventory/issue", {"consumable": "MS-01", "user": "E1", "quantity": 5}).status_code == 200
    assert call("post", "/inventory/issue", {"consumable": "MS-01", "user": "E2", "quantity": 3}).status_code == 200
    s = call("get", "/inventory?consumable=MS-01").get_json()[0]
    assert s["on_hand"] == 112 and s["available"] == 112
    # over-issue refused, nothing written
    assert call("post", "/inventory/issue", {"consumable": "MS-01", "user": "E1", "quantity": 999}).status_code == 409
    assert call("get", "/inventory?consumable=MS-01").get_json()[0]["on_hand"] == 112
    # lock B1: remaining 92 there cannot be issued, only B2's 20 is available
    call("post", "/inventory/batches/lock", {"consumable": "MS-01", "batch_no": "B1", "reason": "质量问题"})
    s = call("get", "/inventory?consumable=MS-01").get_json()[0]
    assert s["available"] == 20
    assert call("post", "/inventory/issue", {"consumable": "MS-01", "user": "E1", "quantity": 21}).status_code == 409
    t = call("get", "/inventory/batches/trace?consumable=MS-01&batch_no=B1").get_json()
    assert sorted((x["user"], x["quantity"]) for x in t["issued_to"]) == [("ls", 3), ("zs", 5)] and t["on_hand"] == 92
    # stocktake correction writes a ledger line
    adj = call("post", "/inventory/adjust", {"consumable": "MS-01", "batch_no": "B2", "counted_quantity": 18}).get_json()
    assert adj["delta"] == -2
    assert call("get", "/inventory/reconcile").get_json()["ok"]
    # ledger is append-only even for raw SQL
    raw = sqlite3.connect(path)
    with pytest.raises(sqlite3.DatabaseError):
        raw.execute("UPDATE inventory_transactions SET quantity=999")
    with pytest.raises(sqlite3.DatabaseError):
        raw.execute("DELETE FROM inventory_transactions")


def test_low_stock_and_anomalies(env):
    _, call, *_ = env
    call("post", "/consumables", {"code": "INK", "name": "墨盒", "safety_stock": 10})
    call("post", "/inventory/receive", {"consumable": "INK", "warehouse": "IT仓库A", "quantity": 5, "batch_no": "X"})
    kinds = [a["kind"] for a in call("get", "/anomalies").get_json()]
    assert "LOW_STOCK" in kinds
    assert call("post", "/notifications/publish").get_json()["new"] >= 1
    assert call("post", "/notifications/publish").get_json()["new"] == 0   # idempotent


def test_serial_tracked_component(env):
    _, call, user, *_ = env
    user("zs", "EMPLOYEE", emp="E1")
    call("post", "/consumables", {"code": "SSD", "name": "SSD 1T", "serial_tracked": True})
    call("post", "/inventory/receive", {"consumable": "SSD", "warehouse": "IT仓库A", "serials": ["S1", "S2"]})
    assert call("post", "/inventory/issue", {"consumable": "SSD", "user": "E1", "serials": ["S1"]}).status_code == 200
    srv = new_asset(call, name="Server-001", category="SV", serial_number="SRV1")
    assert call("post", "/components/install", {"serial": "S1", "asset": srv["asset_code"]}).status_code == 200
    d = call("get", f"/assets/{srv['id']}").get_json()
    assert d["components"] == [{"serial_number": "S1", "name": "SSD 1T"}]
    assert "COMPONENT_INSTALLED" in [e["event_type"] for e in d["timeline"]]


def test_stocktake_flow(env):
    _, call, *_ = env
    a = new_asset(call)
    b = new_asset(call, serial_number="PF4X9")
    c = new_asset(call, serial_number="PF4XA", location="总部-会议室")
    chk = call("post", "/inventory-checks", {"location": "总部-IT仓库"}).get_json()
    assert chk["expected"] == 2
    assert call("post", f"/inventory-checks/{chk['id']}/scan", {"code": a["asset_code"]}).get_json()["result"] == "OK"
    assert call("post", f"/inventory-checks/{chk['id']}/scan", {"code": c["asset_code"]}).get_json()["result"] == "LOCATION_MISMATCH"
    summ = call("post", f"/inventory-checks/{chk['id']}/close").get_json()
    assert summ["scanned"] == 2 and summ["exceptions"] == 2    # one mismatch + one missing (b)


def test_audit_chain_and_append_only(env):
    _, call, _, _, path = env
    new_asset(call)
    v = call("get", "/audit/verify").get_json()
    assert v["ok"] and v["checked"] > 3
    raw = sqlite3.connect(path)
    for sql in ("UPDATE audit_logs SET actor_name='x'", "DELETE FROM audit_logs", "UPDATE asset_events SET event_type='x'", "DELETE FROM asset_events"):
        with pytest.raises(sqlite3.DatabaseError):
            raw.execute(sql)
    # tampering by dropping the trigger is detected by the hash chain
    raw.execute("DROP TRIGGER no_upd_audit")
    raw.execute("UPDATE audit_logs SET new_value='{\"forged\":1}' WHERE id=2")
    raw.commit()
    assert call("get", "/audit/verify").get_json()["ok"] is False


def test_scan_resolve_and_qr_payload(env):
    _, call, user, *_ = env
    user("zs", "EMPLOYEE", emp="E1")
    a = new_asset(call)
    r = call("post", "/scan/resolve", {"code": a["qr_payload"]}).get_json()
    assert r["type"] == "asset" and r["data"]["asset_code"] == a["asset_code"]
    assert call("post", "/scan/resolve", {"code": "E1"}).get_json()["type"] == "user"
    assert call("post", "/scan/resolve", {"code": "ITAM://ASSET/nope"}).status_code == 404


def test_loan_overdue_and_return(env):
    _, call, user, *_ = env
    user("zs", "EMPLOYEE", emp="E1")
    a = new_asset(call)
    assert call("post", f"/assets/{a['id']}/actions/loan", {"user": "E1", "due_date": "2026-01-01"}).status_code == 200
    assert "LOAN_OVERDUE" in [x["kind"] for x in call("get", "/anomalies").get_json()]
    assert call("post", f"/assets/{a['id']}/actions/return", {"location": "总部-IT仓库"}).get_json()["to"] == "IN_STOCK"
    assert "LOAN_OVERDUE" not in [x["kind"] for x in call("get", "/anomalies").get_json()]


def test_unauthenticated_rejected(env):
    app, *_ = env
    c = app.test_client()
    assert c.get("/api/v1/assets").status_code == 401
    assert c.post("/api/v1/auth/login", json={"username": "admin", "password": "wrong"}).status_code == 401
    assert c.get("/api/v1/health").status_code == 200


def test_outbound_repair_sync_failure_then_retry(tmp_path):
    import threading
    from http.server import BaseHTTPRequestHandler, HTTPServer

    seen = []
    state = {"up": False}

    class H(BaseHTTPRequestHandler):
        def do_POST(self):
            raw = self.rfile.read(int(self.headers["Content-Length"]))
            if not state["up"]:
                self.send_response(503)
                self.end_headers()
                return
            seen.append((self.headers["Idempotency-Key"], json.loads(raw)))
            out = json.dumps({"repairId": "R-REMOTE-1", "status": "OPEN"}).encode()
            self.send_response(200)
            self.end_headers()
            self.wfile.write(out)

        def log_message(self, *a):
            pass

    srv = HTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    app = create_app({"DB": str(tmp_path / "s.db"), "ADMIN_PASSWORD": "Admin#12345", "WEBHOOK_SECRET": SECRET,
                      "REPAIR_URL": f"http://127.0.0.1:{srv.server_port}"})
    c = app.test_client()
    H_ = {"Authorization": "Bearer " + c.post("/api/v1/auth/login", json={"username": "admin", "password": "Admin#12345"}).get_json()["token"]}
    call = lambda m, p, d=None: getattr(c, m)("/api/v1" + p, headers=H_, **({"json": d} if d is not None else {}))
    a = new_asset(call := (lambda m, p, d=None: getattr(c, m)("/api/v1" + p, headers=H_, **({"json": d} if d is not None else {}))))
    r = call("post", f"/assets/{a['id']}/actions/repair_request", {"fault": "屏幕碎裂"}).get_json()
    # repair system down: business state is still correct, sync is flagged FAILED
    assert r["to"] == "REPAIR" and r["repair"]["sync"] == "FAILED"
    assert "REPAIR_SYNC_PENDING" in [x["kind"] for x in call("get", "/anomalies").get_json()]
    state["up"] = True
    res = call("post", "/integrations/repair/retry").get_json()
    assert res[0]["sync"] == "SYNCED" and res[0]["remote"] == "R-REMOTE-1"
    assert seen[0][0] == r["ref_no"] and seen[0][1]["assetCode"] == a["asset_code"]
    assert call("post", "/integrations/repair/retry").get_json() == []          # nothing left to push
    logs = call("get", "/integrations/repair/logs").get_json()
    assert [l["ok"] for l in logs] == [1, 0]
    srv.shutdown()
