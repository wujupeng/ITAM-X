"""ITAM-X: IT Asset & Consumable Lifecycle Management."""
__version__ = "1.0.0"
