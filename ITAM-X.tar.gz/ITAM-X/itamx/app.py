"""ITAM-X REST API (Flask)."""
import hashlib
import hmac
import io
import json
import os
import secrets
import sqlite3
import time
import urllib.request
import uuid
from datetime import datetime, timedelta

from flask import Flask, Response, g, jsonify, request, send_from_directory
from werkzeug.security import check_password_hash, generate_password_hash

from . import core
from .core import ALL_ROLES, STAFF, ApiError, Ctx, one, rows
from .db import init_db, tx

API = "/api/v1"
_FAILS = {}   # username -> (count, locked_until)


def seed(db, admin_password):
    """Idempotent bootstrap data."""
    with tx(db):
        if db.execute("SELECT 1 FROM users LIMIT 1").fetchone():
            return False
        for name in ("IT部", "研发部", "生产部", "销售部", "财务部"):
            db.execute("INSERT OR IGNORE INTO departments(name) VALUES(?)", (name,))
        for name in ("总部-IT仓库", "总部-2F研发区", "总部-会议室"):
            db.execute("INSERT OR IGNORE INTO locations(name,uuid) VALUES(?,?)", (name, str(uuid.uuid4())))
        db.execute("INSERT OR IGNORE INTO warehouses(name,uuid) VALUES(?,?)", ("IT仓库A", str(uuid.uuid4())))
        for code, name in (("LT", "笔记本"), ("DT", "台式机"), ("MN", "显示器"), ("PR", "打印机"), ("SV", "服务器"),
                           ("NW", "网络设备"), ("PH", "手机/平板"), ("OT", "其他外设")):
            db.execute("INSERT OR IGNORE INTO asset_categories(code,name) VALUES(?,?)", (code, name))
        db.execute("""INSERT INTO users(uuid,username,emp_no,full_name,password_hash,role,department_id)
            VALUES(?,?,?,?,?,?,(SELECT id FROM departments WHERE name='IT部'))""",
                   (str(uuid.uuid4()), "admin", "EMP00001", "系统管理员", generate_password_hash(admin_password), "SUPER_ADMIN"))
        core.audit(db, Ctx(actor_name="bootstrap"), "BOOTSTRAP", "system", None, None, {"admin": "admin"})
    return True


def create_app(config=None):
    cfg = {
        "DB": os.environ.get("ITAMX_DB", os.path.join(os.getcwd(), "data", "itamx.db")),
        "WEBHOOK_SECRET": os.environ.get("ITAMX_WEBHOOK_SECRET", ""),
        "ALLOW_UNSIGNED_WEBHOOK": os.environ.get("ITAMX_ALLOW_UNSIGNED", "") == "1",
        "REPAIR_URL": os.environ.get("ITAMX_REPAIR_URL", "").rstrip("/"),
        "REPAIR_TOKEN": os.environ.get("ITAMX_REPAIR_TOKEN", ""),
        "ADMIN_PASSWORD": os.environ.get("ITAMX_ADMIN_PASSWORD", ""),
        "SESSION_HOURS": 12,
    }
    cfg.update(config or {})
    os.makedirs(os.path.dirname(os.path.abspath(cfg["DB"])), exist_ok=True)
    app = Flask(__name__, static_folder=None)
    app.config["ITAMX"] = cfg
    app.json.ensure_ascii = False

    boot = init_db(cfg["DB"])
    pw = cfg["ADMIN_PASSWORD"] or secrets.token_urlsafe(12)
    if seed(boot, pw) and not cfg["ADMIN_PASSWORD"]:
        path = os.path.join(os.path.dirname(os.path.abspath(cfg["DB"])), "admin_password.txt")
        with open(path, "w") as f:
            f.write(pw + "\n")
        os.chmod(path, 0o600)
        app.logger.warning("Initial admin password written to %s", path)
    boot.close()

    # ---------------------------------------------------------------- plumbing
    def db():
        if "db" not in g:
            from .db import connect
            g.db = connect(cfg["DB"])
        return g.db

    @app.teardown_appcontext
    def _close(_):
        d = g.pop("db", None)
        if d:
            d.close()

    @app.before_request
    def _ctx():
        g.ctx = Ctx(ip=request.remote_addr or "", terminal=request.headers.get("X-Terminal", request.user_agent.string[:60]),
                    scan_method=request.headers.get("X-Scan-Method", ""),
                    trace_id=request.headers.get("X-Trace-Id") or uuid.uuid4().hex)

    @app.after_request
    def _trace(resp):
        resp.headers["X-Trace-Id"] = g.ctx.trace_id if "ctx" in g else ""
        return resp

    @app.errorhandler(ApiError)
    def _api_error(e):
        return jsonify(error=e.code, message=e.message, trace_id=g.ctx.trace_id), e.status

    @app.errorhandler(sqlite3.IntegrityError)
    def _integrity(e):
        return jsonify(error="conflict", message=str(e), trace_id=g.ctx.trace_id), 409

    @app.errorhandler(sqlite3.DatabaseError)
    def _dberr(e):
        status = 409 if "append-only" in str(e) else 500
        return jsonify(error="database_error", message=str(e), trace_id=g.ctx.trace_id), status

    def authed(roles=None):
        auth = request.headers.get("Authorization", "")
        if not auth.startswith("Bearer "):
            raise ApiError("authentication required", 401, "unauthorized")
        th = hashlib.sha256(auth[7:].encode()).hexdigest()
        row = db().execute("""SELECT u.* FROM sessions s JOIN users u ON u.id=s.user_id
            WHERE s.token=? AND s.expires_at>? AND u.active=1""", (th, core.now())).fetchone()
        if not row:
            raise ApiError("invalid or expired token", 401, "unauthorized")
        g.user = dict(row)
        g.ctx.actor_id, g.ctx.actor_name, g.ctx.role = row["id"], row["username"], row["role"]
        if roles and row["role"] not in roles and row["role"] != "SUPER_ADMIN":
            raise ApiError("forbidden", 403, "forbidden")
        return g.user

    def body():
        d = request.get_json(silent=True)
        if d is None:
            raise ApiError("JSON body required")
        return d

    def write(fn, *a, **kw):
        with tx(db()):
            return fn(db(), g.ctx, *a, **kw)

    def readonly_block():
        if g.ctx.role == "AUDITOR":
            raise ApiError("auditor role is read-only", 403, "forbidden")

    # ---------------------------------------------------------------- static / health
    static_dir = os.path.join(os.path.dirname(__file__), "static")

    @app.get("/")
    def index():
        return send_from_directory(static_dir, "index.html")

    @app.get(API + "/health")
    def health():
        db().execute("SELECT 1")
        return jsonify(status="ok", time=core.now())

    # ---------------------------------------------------------------- auth & master data
    @app.post(API + "/auth/login")
    def login():
        d = body()
        name = d.get("username", "")
        cnt, until = _FAILS.get(name, (0, 0))
        if until > time.time():
            raise ApiError("too many failed attempts, try later", 429, "locked")
        u = db().execute("SELECT * FROM users WHERE username=? AND active=1", (name,)).fetchone()
        if not u or not check_password_hash(u["password_hash"], d.get("password", "")):
            cnt += 1
            _FAILS[name] = (cnt, time.time() + 60 if cnt >= 5 else 0)
            raise ApiError("invalid credentials", 401, "unauthorized")
        _FAILS.pop(name, None)
        token = secrets.token_urlsafe(32)
        exp = (datetime.now() + timedelta(hours=cfg["SESSION_HOURS"])).strftime("%Y-%m-%d %H:%M:%S")
        with tx(db()):
            db().execute("INSERT INTO sessions(token,user_id,created_at,expires_at) VALUES(?,?,?,?)",
                         (hashlib.sha256(token.encode()).hexdigest(), u["id"], core.now(), exp))
            core.audit(db(), Ctx(actor_id=u["id"], actor_name=u["username"], role=u["role"], ip=g.ctx.ip,
                                 terminal=g.ctx.terminal, trace_id=g.ctx.trace_id), "LOGIN", "user", u["id"])
        return jsonify(token=token, expires_at=exp, user={"id": u["id"], "username": u["username"],
                                                           "full_name": u["full_name"], "role": u["role"]})

    @app.get(API + "/auth/me")
    def me():
        u = authed()
        return jsonify({k: u[k] for k in ("id", "username", "full_name", "role", "emp_no", "uuid")})

    @app.get(API + "/users")
    def users_list():
        authed(STAFF | {"AUDITOR", "DEPARTMENT_MANAGER"})
        return jsonify(rows(db().execute("""SELECT u.id,u.uuid,u.username,u.emp_no,u.full_name,u.role,d.name department,u.active
            FROM users u LEFT JOIN departments d ON d.id=u.department_id ORDER BY u.id""")))

    @app.post(API + "/users")
    def users_create():
        authed(core.ADMINS)
        d = body()
        if d.get("role") not in ALL_ROLES:
            raise ApiError(f"role must be one of {sorted(ALL_ROLES)}")
        if len(d.get("password", "")) < 8:
            raise ApiError("password must be at least 8 characters")

        def f(dbc, ctx):
            dept = core._lookup(dbc, "departments", d.get("department"))
            uid = dbc.execute("""INSERT INTO users(uuid,username,emp_no,full_name,password_hash,role,department_id)
                VALUES(?,?,?,?,?,?,?)""", (str(uuid.uuid4()), d["username"], d.get("emp_no"), d.get("full_name", d["username"]),
                                           generate_password_hash(d["password"]), d["role"], dept)).lastrowid
            core.audit(dbc, ctx, "CREATE", "user", uid, None, {"username": d["username"], "role": d["role"]})
            return uid
        return jsonify(id=write(f)), 201

    def simple_master(table, path, cols):
        @app.get(API + path, endpoint=f"{table}_list")
        def _list():
            authed()
            return jsonify(rows(db().execute(f"SELECT * FROM {table} ORDER BY id")))

        @app.post(API + path, endpoint=f"{table}_create")
        def _create():
            authed(core.ADMINS | {"IT_OPERATOR", "WAREHOUSE_ADMIN"})
            d = body()

            def f(dbc, ctx):
                vals = [d.get(c) for c in cols]
                if "uuid" in _cols(table):
                    cols2, vals2 = cols + ["uuid"], vals + [str(uuid.uuid4())]
                else:
                    cols2, vals2 = cols, vals
                rid = dbc.execute(f"INSERT INTO {table}({','.join(cols2)}) VALUES({','.join('?' * len(cols2))})", vals2).lastrowid
                core.audit(dbc, ctx, "CREATE", table, rid, None, d)
                return rid
            return jsonify(id=write(f)), 201

    def _cols(table):
        return [r["name"] for r in db().execute(f"PRAGMA table_info({table})")]

    simple_master("departments", "/departments", ["name"])
    simple_master("locations", "/locations", ["name"])
    simple_master("warehouses", "/warehouses", ["name"])
    simple_master("asset_categories", "/categories", ["code", "name"])

    # ---------------------------------------------------------------- assets
    @app.get(API + "/assets")
    def assets_list():
        u = authed()
        q = request.args
        where, args = ["1=1"], []
        if u["role"] in ("EMPLOYEE",):
            where.append("a.holder_id=?")
            args.append(u["id"])
        for key, col in (("status", "a.status"), ("category", "c.code"), ("holder", "a.holder_id")):
            if q.get(key):
                where.append(f"{col}=?")
                args.append(q[key])
        if q.get("q"):
            where.append("(a.asset_code LIKE ? OR a.name LIKE ? OR a.serial_number LIKE ?)")
            args += [f"%{q['q']}%"] * 3
        sql = f"""SELECT a.id,a.uuid,a.asset_code,a.name,a.brand,a.serial_number,a.status,c.name category,
            h.full_name holder, d.name department, l.name location, a.purchase_price, a.warranty_end
            FROM assets a JOIN asset_categories c ON c.id=a.category_id LEFT JOIN users h ON h.id=a.holder_id
            LEFT JOIN departments d ON d.id=a.department_id LEFT JOIN locations l ON l.id=a.location_id
            WHERE {' AND '.join(where)} ORDER BY a.id DESC LIMIT ? OFFSET ?"""
        args += [min(int(q.get("limit", 200)), 1000), int(q.get("offset", 0))]
        return jsonify(rows(db().execute(sql, args)))

    @app.post(API + "/assets")
    def assets_create():
        authed(STAFF)
        d = body()

        def f(dbc, ctx):
            aid = core.create_asset(dbc, ctx, d)
            if d.get("auto_stock"):   # fast path: walk PURCHASED -> RECEIVED -> INSPECTED -> IN_STOCK, one event each
                for act in ("purchase", "receive", "inspect", "stock_in"):
                    core.apply_action(dbc, ctx, aid, act, {"location": d.get("location")})
            return core.get_asset(dbc, aid)
        a = write(f)
        return jsonify(id=a["id"], asset_code=a["asset_code"], uuid=a["uuid"], status=a["status"],
                       qr_payload=f"ITAM://ASSET/{a['uuid']}"), 201

    def _asset_visible(ref):
        u = authed()
        a = core.asset_dossier(db(), ref)
        if u["role"] == "EMPLOYEE" and a["holder_id"] != u["id"]:
            raise ApiError("forbidden", 403, "forbidden")
        return a

    @app.get(API + "/assets/<ref>")
    def asset_get(ref):
        return jsonify(_asset_visible(ref))

    @app.patch(API + "/assets/<ref>")
    def asset_patch(ref):
        authed(STAFF)
        d = body()
        write(core.update_asset, ref, d)
        return jsonify(core.asset_dossier(db(), ref))

    @app.get(API + "/assets/<ref>/events")
    @app.get(API + "/assets/<ref>/lifecycle")
    def asset_events(ref):
        a = _asset_visible(ref)
        return jsonify(a["timeline"])

    @app.get(API + "/assets/<ref>/repairs")
    def asset_repairs(ref):
        a = _asset_visible(ref)
        return jsonify(a["repairs"])

    @app.get(API + "/assets/<ref>/qr")
    def asset_qr(ref):
        a = _asset_visible(ref)
        payload = f"ITAM://ASSET/{a['uuid']}"
        try:
            import qrcode
            import qrcode.image.svg
        except ImportError:
            return jsonify(error="qr_unavailable", message="install 'qrcode' to render QR images", payload=payload), 501
        img = qrcode.make(payload, image_factory=qrcode.image.svg.SvgPathImage)
        buf = io.BytesIO()
        img.save(buf)
        return Response(buf.getvalue(), mimetype="image/svg+xml")

    @app.post(API + "/assets/<ref>/actions/<action>")
    def asset_action(ref, action):
        authed()
        readonly_block()
        d = body() if request.data else {}
        res = write(lambda dbc, ctx: core.apply_action(dbc, ctx, ref, action, d))
        if action == "repair_request":
            res["repair"] = sync_pending_repairs(only_ref=res["ref_no"])
        return jsonify(res)

    # convenience REST aliases from the spec: /issues /returns /transfers /loans /disposals
    for path, action in (("issues", "issue"), ("returns", "return"), ("transfers", "transfer"), ("loans", "loan")):
        def _mk(action):
            def view():
                authed()
                readonly_block()
                d = body()
                if not d.get("asset"):
                    raise ApiError("'asset' (code/uuid/serial) is required")
                return jsonify(write(lambda dbc, ctx: core.apply_action(dbc, ctx, d["asset"], action, d)))
            return view
        app.add_url_rule(f"{API}/{path}", f"alias_{path}", _mk(action), methods=["POST"])

    # ---------------------------------------------------------------- scan
    @app.post(API + "/scan/resolve")
    def scan_resolve():
        authed()
        return jsonify(core.resolve_scan(db(), body().get("code")))

    # ---------------------------------------------------------------- consumables & inventory
    @app.get(API + "/consumables")
    def consumables_list():
        authed()
        return jsonify(core.stock_summary(db()))

    @app.post(API + "/consumables")
    def consumables_create():
        authed(STAFF)
        return jsonify(id=write(core.create_consumable, body())), 201

    @app.get(API + "/inventory")
    def inventory_summary():
        authed()
        return jsonify(core.stock_summary(db(), request.args.get("consumable")))

    @app.get(API + "/inventory/transactions")
    def inventory_txns():
        authed(STAFF | {"AUDITOR"})
        args, w = [], "1=1"
        if request.args.get("consumable"):
            w += " AND t.consumable_id=?"
            args.append(core.get_consumable(db(), request.args["consumable"])["id"])
        return jsonify(rows(db().execute(f"""SELECT t.*, c.code, b.batch_no FROM inventory_transactions t
            JOIN consumables c ON c.id=t.consumable_id JOIN consumable_batches b ON b.id=t.batch_id
            WHERE {w} ORDER BY t.id DESC LIMIT 500""", args)))

    for name, fn in (("receive", core.receive_stock), ("issue", core.issue_stock), ("return", core.return_stock),
                     ("scrap", core.scrap_stock), ("adjust", core.adjust_stock)):
        def _mk(fn):
            def view():
                authed()
                readonly_block()
                return jsonify(write(fn, body()))
            return view
        app.add_url_rule(f"{API}/inventory/{name}", f"inv_{name}", _mk(fn), methods=["POST"])

    @app.post(API + "/inventory/batches/lock")
    def batch_lock():
        authed(core.ADMINS | {"WAREHOUSE_ADMIN"})
        d = body()
        write(core.lock_batch, d.get("consumable"), d.get("batch_no"), bool(d.get("locked", True)), d.get("reason"))
        return jsonify(ok=True)

    @app.get(API + "/inventory/batches/trace")
    def batch_trace():
        authed(STAFF | {"AUDITOR"})
        return jsonify(core.trace_batch(db(), request.args.get("consumable"), request.args.get("batch_no")))

    @app.get(API + "/inventory/reconcile")
    def reconcile():
        authed(STAFF | {"AUDITOR"})
        return jsonify(core.reconcile_inventory(db()))

    @app.post(API + "/components/install")
    def comp_install():
        authed(STAFF)
        d = body()
        write(core.serial_install, d["serial"], d["asset"], bool(d.get("remove")))
        return jsonify(ok=True)

    # ---------------------------------------------------------------- stocktake
    @app.post(API + "/inventory-checks")
    def check_create():
        authed(STAFF)
        return jsonify(write(core.create_check, body().get("location"))), 201

    @app.get(API + "/inventory-checks")
    def check_list():
        authed(STAFF | {"AUDITOR"})
        return jsonify(rows(db().execute("""SELECT c.*, l.name location FROM inventory_checks c
            JOIN locations l ON l.id=c.location_id ORDER BY c.id DESC""")))

    @app.get(API + "/inventory-checks/<cid>")
    def check_get(cid):
        authed(STAFF | {"AUDITOR"})
        chk = one(db().execute("SELECT * FROM inventory_checks WHERE id=? OR check_no=?", (cid if cid.isdigit() else -1, cid)))
        if not chk:
            raise ApiError("not found", 404, "not_found")
        items = rows(db().execute("""SELECT i.*, a.asset_code, a.name FROM inventory_check_items i
            JOIN assets a ON a.id=i.asset_id WHERE i.check_id=?""", (chk["id"],)))
        return jsonify({**chk, **core.check_summary(db(), chk["id"]), "items": items})

    @app.post(API + "/inventory-checks/<cid>/scan")
    def check_scan(cid):
        authed(STAFF)
        return jsonify(write(core.scan_check, cid, body().get("code")))

    @app.post(API + "/inventory-checks/<cid>/close")
    def check_close(cid):
        authed(STAFF)
        return jsonify(write(core.close_check, cid))

    @app.get(API + "/disposals")
    def disposals():
        authed(STAFF | {"AUDITOR"})
        return jsonify(rows(db().execute("""SELECT o.*, a.asset_code, a.name FROM disposal_orders o
            JOIN assets a ON a.id=o.asset_id ORDER BY o.id DESC""")))

    # ---------------------------------------------------------------- repair integration
    def sync_pending_repairs(only_ref=None):
        """Push unsynced repairs to the repair system. Business state never depends on this call succeeding."""
        results = []
        pend = rows(db().execute("""SELECT * FROM asset_repairs WHERE sync_status IN ('PENDING','FAILED') AND status='OPEN'
            AND (? IS NULL OR local_no=?)""", (only_ref, only_ref)))
        for r in pend:
            if not cfg["REPAIR_URL"]:
                with tx(db()):
                    db().execute("UPDATE asset_repairs SET sync_status='LOCAL' WHERE id=?", (r["id"],))
                results.append({"repair": r["local_no"], "sync": "LOCAL"})
                continue
            payload = repair_payload_for(r)
            raw = json.dumps(payload, ensure_ascii=False).encode()
            headers = {"Content-Type": "application/json", "Idempotency-Key": r["local_no"],
                       "X-Trace-Id": g.ctx.trace_id,
                       "X-Signature": "sha256=" + hmac.new(cfg["WEBHOOK_SECRET"].encode(), raw, hashlib.sha256).hexdigest()}
            if cfg["REPAIR_TOKEN"]:
                headers["Authorization"] = "Bearer " + cfg["REPAIR_TOKEN"]
            ok, resp_text, remote = False, "", None
            try:
                req = urllib.request.Request(cfg["REPAIR_URL"] + "/api/v1/repairs", data=raw, headers=headers, method="POST")
                with urllib.request.urlopen(req, timeout=8) as resp:
                    resp_text = resp.read().decode()[:2000]
                    remote = json.loads(resp_text).get("repairId")
                    ok = bool(remote)
            except Exception as ex:   # network / HTTP / JSON errors -> compensate later via retry
                resp_text = f"{type(ex).__name__}: {ex}"
            with tx(db()):
                core.log_integration(db(), "OUT", "POST /api/v1/repairs", payload, resp_text, ok, g.ctx.trace_id)
                if ok:
                    core.mark_synced(db(), r["id"], remote)
                else:
                    db().execute("UPDATE asset_repairs SET sync_status='FAILED' WHERE id=?", (r["id"],))
            results.append({"repair": r["local_no"], "sync": "SYNCED" if ok else "FAILED", "remote": remote})
        return results[0] if only_ref and results else results

    def repair_payload_for(r):
        return core.repair_payload(db(), r)

    @app.post(API + "/integrations/repair/retry")
    def repair_retry():
        authed(core.ADMINS | {"IT_OPERATOR"})
        return jsonify(sync_pending_repairs())

    @app.get(API + "/integrations/repair/logs")
    def repair_logs():
        authed(STAFF | {"AUDITOR"})
        return jsonify(rows(db().execute("SELECT * FROM integration_logs ORDER BY id DESC LIMIT 200")))

    @app.get(API + "/repairs")
    def repairs_list():
        authed(STAFF | {"AUDITOR", "REPAIR_OPERATOR"})
        return jsonify(rows(db().execute("""SELECT p.*, a.asset_code, a.name FROM asset_repairs p
            JOIN assets a ON a.id=p.asset_id ORDER BY p.id DESC LIMIT 500""")))

    def _verify_signature(raw):
        secret = cfg["WEBHOOK_SECRET"]
        if not secret:
            if cfg["ALLOW_UNSIGNED_WEBHOOK"]:
                return
            raise ApiError("webhook secret not configured (set ITAMX_WEBHOOK_SECRET)", 503, "webhook_disabled")
        sig = request.headers.get("X-Signature", "").removeprefix("sha256=")
        good = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, good):
            raise ApiError("invalid signature", 401, "bad_signature")

    @app.post(API + "/webhooks/repair-events")
    @app.post(API + "/webhooks/repair")
    def repair_webhook():
        raw = request.get_data()
        try:
            _verify_signature(raw)
            d = json.loads(raw or b"{}")
            with tx(db()):
                res = core.handle_repair_webhook(db(), g.ctx, d)
            code = 200
        except ApiError as e:
            with tx(db()):
                core.log_integration(db(), "IN", request.path, {"raw": raw.decode(errors="replace")[:2000]}, e.message, False, g.ctx.trace_id)
            raise
        with tx(db()):
            core.log_integration(db(), "IN", request.path, d, res, True, g.ctx.trace_id)
        return jsonify(res), code

    # ---------------------------------------------------------------- reports, audit
    @app.get(API + "/reports/overview")
    def report_overview():
        authed(STAFF | {"AUDITOR", "DEPARTMENT_MANAGER"})
        return jsonify(core.reports_overview(db()))

    @app.get(API + "/anomalies")
    def anomalies():
        authed(STAFF | {"AUDITOR"})
        return jsonify(core.anomalies(db()))

    @app.post(API + "/notifications/publish")
    def notif_publish():
        authed(core.ADMINS)
        with tx(db()):
            n = core.publish_notifications(db())
        return jsonify(new=n)

    @app.get(API + "/notifications")
    def notif_list():
        authed(STAFF | {"AUDITOR"})
        return jsonify(rows(db().execute("SELECT * FROM notifications ORDER BY id DESC LIMIT 200")))

    @app.get(API + "/audit-logs")
    def audit_logs():
        authed(core.ADMINS | {"AUDITOR"})
        return jsonify(rows(db().execute("SELECT * FROM audit_logs ORDER BY id DESC LIMIT ?", (min(int(request.args.get("limit", 200)), 2000),))))

    @app.get(API + "/audit/verify")
    def audit_verify():
        authed(core.ADMINS | {"AUDITOR"})
        return jsonify(core.verify_audit_chain(db()))

    return app
