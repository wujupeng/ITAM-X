"""SQLite storage. Events, audit logs and inventory ledger are append-only (DB triggers)."""
import sqlite3
from contextlib import contextmanager

SCHEMA = """
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS departments(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS locations(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, uuid TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS warehouses(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, uuid TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, uuid TEXT UNIQUE NOT NULL,
  username TEXT UNIQUE NOT NULL, emp_no TEXT UNIQUE, full_name TEXT NOT NULL,
  password_hash TEXT NOT NULL, role TEXT NOT NULL,
  department_id INTEGER REFERENCES departments(id), active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
  created_at TEXT NOT NULL, expires_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS asset_categories(
  id INTEGER PRIMARY KEY, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS asset_models(
  id INTEGER PRIMARY KEY, category_id INTEGER NOT NULL REFERENCES asset_categories(id),
  brand TEXT, name TEXT NOT NULL, UNIQUE(brand,name));
CREATE TABLE IF NOT EXISTS code_sequences(
  key TEXT PRIMARY KEY, value INTEGER NOT NULL);

CREATE TABLE IF NOT EXISTS assets(
  id INTEGER PRIMARY KEY, uuid TEXT UNIQUE NOT NULL, asset_code TEXT UNIQUE NOT NULL,
  category_id INTEGER NOT NULL REFERENCES asset_categories(id),
  model_id INTEGER REFERENCES asset_models(id),
  name TEXT NOT NULL, brand TEXT, serial_number TEXT UNIQUE, mac TEXT,
  status TEXT NOT NULL DEFAULT 'DRAFT',
  holder_id INTEGER REFERENCES users(id),
  department_id INTEGER REFERENCES departments(id),
  location_id INTEGER REFERENCES locations(id),
  parent_asset_id INTEGER REFERENCES assets(id),
  purchase_price REAL, purchase_date TEXT, stock_in_date TEXT,
  warranty_start TEXT, warranty_end TEXT, supplier TEXT, notes TEXT,
  created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_assets_status ON assets(status);
CREATE INDEX IF NOT EXISTS ix_assets_holder ON assets(holder_id);

-- append-only business event stream (one event per business action)
CREATE TABLE IF NOT EXISTS asset_events(
  id INTEGER PRIMARY KEY, event_no TEXT UNIQUE NOT NULL, asset_id INTEGER NOT NULL REFERENCES assets(id),
  event_type TEXT NOT NULL, from_status TEXT, to_status TEXT,
  actor_id INTEGER, target_user_id INTEGER, department_id INTEGER, location_id INTEGER,
  ref_no TEXT, scan_method TEXT, terminal TEXT, payload TEXT, trace_id TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_events_asset ON asset_events(asset_id, id);

-- append-only, hash-chained audit log
CREATE TABLE IF NOT EXISTS audit_logs(
  id INTEGER PRIMARY KEY, action TEXT NOT NULL, entity TEXT, entity_id TEXT,
  actor_id INTEGER, actor_name TEXT, old_value TEXT, new_value TEXT,
  ip TEXT, terminal TEXT, trace_id TEXT, created_at TEXT NOT NULL,
  prev_hash TEXT NOT NULL, hash TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS asset_loans(
  id INTEGER PRIMARY KEY, asset_id INTEGER NOT NULL REFERENCES assets(id),
  borrower_id INTEGER NOT NULL REFERENCES users(id), due_date TEXT,
  loaned_at TEXT NOT NULL, returned_at TEXT);
CREATE TABLE IF NOT EXISTS asset_assignments(
  id INTEGER PRIMARY KEY, asset_id INTEGER NOT NULL REFERENCES assets(id),
  user_id INTEGER NOT NULL REFERENCES users(id), department_id INTEGER, location_id INTEGER,
  accessories TEXT, signature TEXT, photo TEXT,
  assigned_at TEXT NOT NULL, released_at TEXT);
CREATE TABLE IF NOT EXISTS asset_transfers(
  id INTEGER PRIMARY KEY, asset_id INTEGER NOT NULL REFERENCES assets(id),
  from_user_id INTEGER, to_user_id INTEGER, from_department_id INTEGER, to_department_id INTEGER,
  from_location_id INTEGER, to_location_id INTEGER, actor_id INTEGER, created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS disposal_orders(
  id INTEGER PRIMARY KEY, order_no TEXT UNIQUE NOT NULL, asset_id INTEGER NOT NULL REFERENCES assets(id),
  reason TEXT, status TEXT NOT NULL, requested_by INTEGER NOT NULL, approved_by INTEGER,
  requested_at TEXT NOT NULL, decided_at TEXT, method TEXT);

CREATE TABLE IF NOT EXISTS asset_repairs(
  id INTEGER PRIMARY KEY, local_no TEXT UNIQUE NOT NULL, asset_id INTEGER NOT NULL REFERENCES assets(id),
  remote_repair_id TEXT UNIQUE, status TEXT NOT NULL, sync_status TEXT NOT NULL,
  fault TEXT, result TEXT, cost REAL, reported_by INTEGER,
  opened_at TEXT NOT NULL, completed_at TEXT);
CREATE TABLE IF NOT EXISTS webhook_events(
  id INTEGER PRIMARY KEY, event_id TEXT UNIQUE NOT NULL, event_type TEXT NOT NULL,
  body TEXT NOT NULL, result TEXT, received_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS integration_logs(
  id INTEGER PRIMARY KEY, direction TEXT NOT NULL, endpoint TEXT, request TEXT, response TEXT,
  ok INTEGER NOT NULL, trace_id TEXT, created_at TEXT NOT NULL);

CREATE TABLE IF NOT EXISTS consumables(
  id INTEGER PRIMARY KEY, uuid TEXT UNIQUE NOT NULL, code TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
  spec TEXT, brand TEXT, unit TEXT NOT NULL DEFAULT 'pcs', safety_stock REAL NOT NULL DEFAULT 0,
  unit_cost REAL, serial_tracked INTEGER NOT NULL DEFAULT 0, active INTEGER NOT NULL DEFAULT 1);
CREATE TABLE IF NOT EXISTS consumable_batches(
  id INTEGER PRIMARY KEY, consumable_id INTEGER NOT NULL REFERENCES consumables(id),
  batch_no TEXT NOT NULL, warehouse_id INTEGER NOT NULL REFERENCES warehouses(id),
  expiry_date TEXT, locked INTEGER NOT NULL DEFAULT 0, lock_reason TEXT,
  received_at TEXT NOT NULL, UNIQUE(consumable_id,batch_no,warehouse_id));
-- append-only inventory ledger: the single source of truth for stock
CREATE TABLE IF NOT EXISTS inventory_transactions(
  id INTEGER PRIMARY KEY, txn_no TEXT UNIQUE NOT NULL,
  consumable_id INTEGER NOT NULL REFERENCES consumables(id),
  batch_id INTEGER NOT NULL REFERENCES consumable_batches(id),
  txn_type TEXT NOT NULL, quantity REAL NOT NULL,
  to_user_id INTEGER, to_department_id INTEGER, ref_no TEXT, actor_id INTEGER,
  note TEXT, trace_id TEXT, created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS ix_txn_batch ON inventory_transactions(batch_id);
CREATE TABLE IF NOT EXISTS consumable_serials(
  id INTEGER PRIMARY KEY, consumable_id INTEGER NOT NULL REFERENCES consumables(id),
  serial_number TEXT UNIQUE NOT NULL, batch_id INTEGER REFERENCES consumable_batches(id),
  status TEXT NOT NULL DEFAULT 'IN_STOCK', installed_in_asset_id INTEGER REFERENCES assets(id));

CREATE TABLE IF NOT EXISTS inventory_checks(
  id INTEGER PRIMARY KEY, check_no TEXT UNIQUE NOT NULL, location_id INTEGER NOT NULL REFERENCES locations(id),
  status TEXT NOT NULL, created_by INTEGER NOT NULL, created_at TEXT NOT NULL, closed_at TEXT);
CREATE TABLE IF NOT EXISTS inventory_check_items(
  id INTEGER PRIMARY KEY, check_id INTEGER NOT NULL REFERENCES inventory_checks(id),
  asset_id INTEGER NOT NULL REFERENCES assets(id), expected_location_id INTEGER,
  scanned INTEGER NOT NULL DEFAULT 0, actual_location_id INTEGER, result TEXT,
  scanned_at TEXT, UNIQUE(check_id,asset_id));
CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY, kind TEXT NOT NULL, message TEXT NOT NULL, ref TEXT,
  created_at TEXT NOT NULL, UNIQUE(kind,ref));

-- Append-only guards: history can never be rewritten, even by direct SQL.
CREATE TRIGGER IF NOT EXISTS no_upd_events BEFORE UPDATE ON asset_events
  BEGIN SELECT RAISE(ABORT,'asset_events is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_del_events BEFORE DELETE ON asset_events
  BEGIN SELECT RAISE(ABORT,'asset_events is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_upd_audit BEFORE UPDATE ON audit_logs
  BEGIN SELECT RAISE(ABORT,'audit_logs is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_del_audit BEFORE DELETE ON audit_logs
  BEGIN SELECT RAISE(ABORT,'audit_logs is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_upd_txn BEFORE UPDATE ON inventory_transactions
  BEGIN SELECT RAISE(ABORT,'inventory_transactions is append-only'); END;
CREATE TRIGGER IF NOT EXISTS no_del_txn BEFORE DELETE ON inventory_transactions
  BEGIN SELECT RAISE(ABORT,'inventory_transactions is append-only'); END;
"""


def connect(path):
    db = sqlite3.connect(path, isolation_level=None, timeout=30)
    db.row_factory = sqlite3.Row
    db.execute("PRAGMA foreign_keys=ON")
    return db


def init_db(path):
    db = connect(path)
    db.executescript(SCHEMA)
    return db


@contextmanager
def tx(db):
    """Serialised write transaction (BEGIN IMMEDIATE) - also keeps the audit hash chain consistent."""
    db.execute("BEGIN IMMEDIATE")
    try:
        yield db
        db.execute("COMMIT")
    except BaseException:
        db.execute("ROLLBACK")
        raise
