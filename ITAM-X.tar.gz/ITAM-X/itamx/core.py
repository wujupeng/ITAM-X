"""ITAM-X business core: lifecycle state machine, events, audit chain, inventory ledger, repair sync."""
import hashlib
import json
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from .db import tx


class ApiError(Exception):
    def __init__(self, message, status=400, code="bad_request"):
        super().__init__(message)
        self.message, self.status, self.code = message, status, code


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def rows(cur):
    return [dict(r) for r in cur.fetchall()]


def one(cur):
    r = cur.fetchone()
    return dict(r) if r else None


@dataclass
class Ctx:
    actor_id: int = None
    actor_name: str = "system"
    role: str = "SYSTEM"
    ip: str = ""
    terminal: str = ""
    scan_method: str = ""
    trace_id: str = field(default_factory=lambda: uuid.uuid4().hex)


# ------------------------------------------------------------------ permissions
STAFF = {"SUPER_ADMIN", "IT_ADMIN", "IT_OPERATOR", "WAREHOUSE_ADMIN"}
ADMINS = {"SUPER_ADMIN", "IT_ADMIN"}
ALL_ROLES = STAFF | {"DEPARTMENT_MANAGER", "EMPLOYEE", "AUDITOR", "REPAIR_OPERATOR"}

# asset lifecycle action -> (allowed from-states, to-state, allowed roles)
ACTIONS = {
    "purchase":       ({"DRAFT"}, "PURCHASED", STAFF),
    "receive":        ({"PURCHASED"}, "RECEIVED", STAFF),
    "inspect":        ({"RECEIVED"}, "INSPECTED", STAFF),
    "stock_in":       ({"INSPECTED"}, "IN_STOCK", STAFF),
    "issue":          ({"IN_STOCK", "READY_FOR_USE"}, "IN_USE", STAFF),
    "return":         ({"IN_USE", "LOANED"}, "IN_STOCK", STAFF | {"EMPLOYEE", "DEPARTMENT_MANAGER"}),
    "transfer":       ({"IN_USE"}, "IN_USE", STAFF),
    "loan":           ({"IN_STOCK"}, "LOANED", STAFF),
    "repair_request": ({"IN_USE", "IN_STOCK", "LOANED"}, "REPAIR", STAFF | {"EMPLOYEE", "DEPARTMENT_MANAGER"}),
    "repair_complete": ({"REPAIR"}, "READY_FOR_USE", {"SYSTEM", "REPAIR_OPERATOR"} | ADMINS),
    "restock":        ({"READY_FOR_USE"}, "IN_STOCK", STAFF),
    "retire_request": ({"IN_STOCK", "IN_USE", "READY_FOR_USE"}, "RETIREMENT_PENDING", STAFF),
    "retire_reject":  ({"RETIREMENT_PENDING"}, "IN_STOCK", ADMINS),
    "scrap":          ({"RETIREMENT_PENDING"}, "SCRAPPED", ADMINS),
    "dispose":        ({"SCRAPPED"}, "DISPOSED", ADMINS),
}
EVENT_NAMES = {
    "purchase": "ASSET_PURCHASED", "receive": "ASSET_RECEIVED", "inspect": "ASSET_INSPECTED",
    "stock_in": "ASSET_STOCKED_IN", "issue": "ASSET_ISSUED", "return": "ASSET_RETURNED",
    "transfer": "ASSET_TRANSFERRED", "loan": "ASSET_LOANED", "repair_request": "REPAIR_REQUESTED",
    "repair_complete": "REPAIR_COMPLETED", "restock": "ASSET_RESTOCKED",
    "retire_request": "RETIREMENT_REQUESTED", "retire_reject": "RETIREMENT_REJECTED",
    "scrap": "ASSET_SCRAPPED", "dispose": "ASSET_DISPOSED",
}


def require_role(ctx, roles):
    if ctx.role not in roles:
        raise ApiError(f"role {ctx.role} is not allowed to do this", 403, "forbidden")


# ------------------------------------------------------------------ audit chain
def _canon(d):
    return json.dumps(d, sort_keys=True, ensure_ascii=False, default=str)


def audit(db, ctx, action, entity=None, entity_id=None, old=None, new=None):
    last = db.execute("SELECT hash FROM audit_logs ORDER BY id DESC LIMIT 1").fetchone()
    prev = last["hash"] if last else "GENESIS"
    rec = dict(action=action, entity=entity, entity_id=str(entity_id) if entity_id is not None else None,
               actor_id=ctx.actor_id, actor_name=ctx.actor_name,
               old_value=_canon(old) if old is not None else None,
               new_value=_canon(new) if new is not None else None,
               ip=ctx.ip, terminal=ctx.terminal, trace_id=ctx.trace_id, created_at=now())
    h = hashlib.sha256((prev + _canon(rec)).encode()).hexdigest()
    db.execute("""INSERT INTO audit_logs(action,entity,entity_id,actor_id,actor_name,old_value,new_value,
                  ip,terminal,trace_id,created_at,prev_hash,hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
               (rec["action"], rec["entity"], rec["entity_id"], rec["actor_id"], rec["actor_name"],
                rec["old_value"], rec["new_value"], rec["ip"], rec["terminal"], rec["trace_id"],
                rec["created_at"], prev, h))


def verify_audit_chain(db):
    prev, n = "GENESIS", 0
    for r in db.execute("SELECT * FROM audit_logs ORDER BY id"):
        rec = dict(action=r["action"], entity=r["entity"], entity_id=r["entity_id"], actor_id=r["actor_id"],
                   actor_name=r["actor_name"], old_value=r["old_value"], new_value=r["new_value"], ip=r["ip"],
                   terminal=r["terminal"], trace_id=r["trace_id"], created_at=r["created_at"])
        if r["prev_hash"] != prev or hashlib.sha256((prev + _canon(rec)).encode()).hexdigest() != r["hash"]:
            return {"ok": False, "broken_at": r["id"], "checked": n}
        prev, n = r["hash"], n + 1
    return {"ok": True, "checked": n}


def next_seq(db, key):
    db.execute("INSERT INTO code_sequences(key,value) VALUES(?,1) ON CONFLICT(key) DO UPDATE SET value=value+1", (key,))
    return db.execute("SELECT value FROM code_sequences WHERE key=?", (key,)).fetchone()[0]


# ------------------------------------------------------------------ master data
def get_asset(db, ref):
    """ref: numeric id, uuid, asset_code or serial number."""
    q = "SELECT * FROM assets WHERE "
    row = None
    if isinstance(ref, int) or str(ref).isdigit():
        row = db.execute(q + "id=?", (int(ref),)).fetchone()
    if not row:
        row = db.execute(q + "uuid=? OR asset_code=? OR serial_number=?", (str(ref),) * 3).fetchone()
    if not row:
        raise ApiError("asset not found", 404, "not_found")
    return dict(row)


def get_user(db, ref):
    if ref is None:
        return None
    row = db.execute("SELECT * FROM users WHERE id=? OR uuid=? OR emp_no=? OR username=?",
                     (ref if str(ref).isdigit() else -1, str(ref), str(ref), str(ref))).fetchone()
    if not row:
        raise ApiError(f"user {ref} not found", 404, "not_found")
    return dict(row)


def _lookup(db, table, ref, col="name"):
    if ref in (None, ""):
        return None
    row = db.execute(f"SELECT id FROM {table} WHERE id=? OR {col}=?", (ref if str(ref).isdigit() else -1, str(ref))).fetchone()
    if not row:
        raise ApiError(f"{table} '{ref}' not found", 404, "not_found")
    return row["id"]


def create_asset(db, ctx, d):
    require_role(ctx, STAFF)
    if not d.get("name"):
        raise ApiError("name is required")
    cat = db.execute("SELECT * FROM asset_categories WHERE id=? OR code=?",
                     (d.get("category_id") if str(d.get("category_id", "")).isdigit() else -1, d.get("category"))).fetchone()
    if not cat:
        raise ApiError("category not found (use category code e.g. LT, DT, SV)", 404, "not_found")
    sn = d.get("serial_number") or None
    if sn and db.execute("SELECT 1 FROM assets WHERE serial_number=?", (sn,)).fetchone():
        raise ApiError(f"duplicate serial number {sn}", 409, "duplicate_sn")
    year = (d.get("purchase_date") or now())[:4]
    seq = next_seq(db, "asset:%s:%s" % (cat["code"], year))
    code = "IT-%s-%s-%05d" % (cat["code"], year, seq)
    ts, uid = now(), str(uuid.uuid4())
    cur = db.execute("""INSERT INTO assets(uuid,asset_code,category_id,name,brand,serial_number,mac,status,
        department_id,location_id,purchase_price,purchase_date,warranty_start,warranty_end,supplier,notes,created_at,updated_at)
        VALUES(?,?,?,?,?,?,?,'DRAFT',?,?,?,?,?,?,?,?,?,?)""",
                     (uid, code, cat["id"], d["name"], d.get("brand"), sn, d.get("mac"),
                      _lookup(db, "departments", d.get("department")), _lookup(db, "locations", d.get("location")),
                      d.get("purchase_price"), d.get("purchase_date"), d.get("warranty_start"), d.get("warranty_end"),
                      d.get("supplier"), d.get("notes"), ts, ts))
    aid = cur.lastrowid
    _event(db, ctx, aid, "ASSET_CREATED", None, "DRAFT", payload={"asset_code": code})
    audit(db, ctx, "CREATE", "asset", aid, None, {"asset_code": code, "name": d["name"]})
    return aid


EDITABLE = {"name", "brand", "mac", "notes", "supplier", "warranty_start", "warranty_end", "purchase_price", "purchase_date"}


def update_asset(db, ctx, ref, d):
    require_role(ctx, STAFF)
    a = get_asset(db, ref)
    if "status" in d or "holder_id" in d:
        raise ApiError("status/holder can only change through business actions", 400, "direct_state_change_forbidden")
    changes = {k: v for k, v in d.items() if k in EDITABLE}
    if not changes:
        raise ApiError("nothing to update")
    sets = ", ".join(f"{k}=?" for k in changes)
    db.execute(f"UPDATE assets SET {sets}, updated_at=? WHERE id=?", (*changes.values(), now(), a["id"]))
    audit(db, ctx, "UPDATE", "asset", a["id"], {k: a[k] for k in changes}, changes)


def _event(db, ctx, asset_id, etype, frm, to, target_user=None, dept=None, loc=None, ref_no=None, payload=None):
    n = next_seq(db, "event:" + now()[:10])
    no = f"EVENT-{now()[:10].replace('-', '')}-{n:06d}"
    db.execute("""INSERT INTO asset_events(event_no,asset_id,event_type,from_status,to_status,actor_id,target_user_id,
        department_id,location_id,ref_no,scan_method,terminal,payload,trace_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
               (no, asset_id, etype, frm, to, ctx.actor_id, target_user, dept, loc, ref_no, ctx.scan_method,
                ctx.terminal, _canon(payload) if payload is not None else None, ctx.trace_id, now()))
    return no


# ------------------------------------------------------------------ lifecycle engine
def apply_action(db, ctx, ref, action, d=None):
    """The ONLY way an asset changes status/holder. Must be called inside tx()."""
    d = d or {}
    if action not in ACTIONS:
        raise ApiError(f"unknown action '{action}'", 400, "unknown_action")
    frm_states, to_state, roles = ACTIONS[action]
    require_role(ctx, roles)
    a = get_asset(db, ref)
    if a["status"] not in frm_states:
        raise ApiError(f"cannot {action} an asset in status {a['status']} (allowed: {sorted(frm_states)})",
                       409, "invalid_transition")
    old = {"status": a["status"], "holder_id": a["holder_id"], "department_id": a["department_id"], "location_id": a["location_id"]}
    holder, dept, loc = a["holder_id"], a["department_id"], a["location_id"]
    ts, ref_no, target = now(), d.get("ref_no"), None
    extra = {}

    if ctx.role in {"EMPLOYEE", "DEPARTMENT_MANAGER"} and action in {"return", "repair_request"}:
        if a["holder_id"] != ctx.actor_id:
            raise ApiError("you can only act on assets you hold", 403, "forbidden")

    if action == "issue":
        u = get_user(db, d.get("user") or d.get("user_id") or (holder if a["status"] == "READY_FOR_USE" else None))
        if not u:
            raise ApiError("'user' (employee scan) is required for issue")
        holder, target = u["id"], u["id"]
        dept = u["department_id"] or dept
        loc = _lookup(db, "locations", d.get("location")) or loc
        if a["status"] == "IN_STOCK":
            db.execute("""INSERT INTO asset_assignments(asset_id,user_id,department_id,location_id,accessories,signature,photo,assigned_at)
                VALUES(?,?,?,?,?,?,?,?)""", (a["id"], holder, dept, loc, json.dumps(d.get("accessories") or [], ensure_ascii=False),
                                              d.get("signature"), d.get("photo"), ts))
        extra = {"accessories": d.get("accessories") or [], "signed": bool(d.get("signature"))}
    elif action == "return":
        db.execute("UPDATE asset_assignments SET released_at=? WHERE asset_id=? AND released_at IS NULL", (ts, a["id"]))
        db.execute("UPDATE asset_loans SET returned_at=? WHERE asset_id=? AND returned_at IS NULL", (ts, a["id"]))
        target, holder, dept = a["holder_id"], None, None
        loc = _lookup(db, "locations", d.get("location")) or loc
    elif action == "restock":
        db.execute("UPDATE asset_assignments SET released_at=? WHERE asset_id=? AND released_at IS NULL", (ts, a["id"]))
        holder, dept = None, None
        loc = _lookup(db, "locations", d.get("location")) or loc
    elif action == "transfer":
        to_user = get_user(db, d.get("to_user")) if d.get("to_user") else None
        to_dept = _lookup(db, "departments", d.get("to_department"))
        to_loc = _lookup(db, "locations", d.get("to_location"))
        if not (to_user or to_dept or to_loc):
            raise ApiError("transfer needs to_user, to_department or to_location")
        new_holder = to_user["id"] if to_user else holder
        new_dept = to_dept or (to_user["department_id"] if to_user else dept)
        new_loc = to_loc or loc
        db.execute("""INSERT INTO asset_transfers(asset_id,from_user_id,to_user_id,from_department_id,to_department_id,
            from_location_id,to_location_id,actor_id,created_at) VALUES(?,?,?,?,?,?,?,?,?)""",
                   (a["id"], holder, new_holder, dept, new_dept, loc, new_loc, ctx.actor_id, ts))
        if to_user and to_user["id"] != holder:
            db.execute("UPDATE asset_assignments SET released_at=? WHERE asset_id=? AND released_at IS NULL", (ts, a["id"]))
            db.execute("INSERT INTO asset_assignments(asset_id,user_id,department_id,location_id,assigned_at) VALUES(?,?,?,?,?)",
                       (a["id"], new_holder, new_dept, new_loc, ts))
        holder, dept, loc, target = new_holder, new_dept, new_loc, new_holder
    elif action == "loan":
        u = get_user(db, d.get("user") or d.get("user_id"))
        if not u:
            raise ApiError("'user' is required for loan")
        holder, target, dept = u["id"], u["id"], u["department_id"]
        db.execute("INSERT INTO asset_loans(asset_id,borrower_id,due_date,loaned_at) VALUES(?,?,?,?)",
                   (a["id"], holder, d.get("due_date"), ts))
        extra = {"due_date": d.get("due_date")}
    elif action == "repair_request":
        if not d.get("fault"):
            raise ApiError("'fault' description is required")
        n = next_seq(db, "repair:" + ts[:10])
        local_no = f"RP-{ts[:10].replace('-', '')}-{n:04d}"
        db.execute("""INSERT INTO asset_repairs(local_no,asset_id,status,sync_status,fault,reported_by,opened_at)
            VALUES(?,?,'OPEN','PENDING',?,?,?)""", (local_no, a["id"], d["fault"], ctx.actor_id, ts))
        ref_no, extra = local_no, {"fault": d["fault"]}
    elif action == "repair_complete":
        extra = {"result": d.get("result"), "cost": d.get("cost")}
    elif action == "retire_request":
        n = next_seq(db, "disposal:" + ts[:10])
        ref_no = f"DSP-{ts[:10].replace('-', '')}-{n:04d}"
        db.execute("""INSERT INTO disposal_orders(order_no,asset_id,reason,status,requested_by,requested_at)
            VALUES(?,?,?,'PENDING',?,?)""", (ref_no, a["id"], d.get("reason"), ctx.actor_id, ts))
        extra = {"reason": d.get("reason")}
    elif action in {"scrap", "retire_reject"}:
        order = one(db.execute("SELECT * FROM disposal_orders WHERE asset_id=? AND status='PENDING' ORDER BY id DESC", (a["id"],)))
        if not order:
            raise ApiError("no pending disposal order", 409, "no_order")
        if action == "scrap" and order["requested_by"] == ctx.actor_id and ctx.role != "SUPER_ADMIN":
            raise ApiError("approver must differ from requester (four-eyes)", 403, "four_eyes")
        db.execute("UPDATE disposal_orders SET status=?, approved_by=?, decided_at=? WHERE id=?",
                   ("APPROVED" if action == "scrap" else "REJECTED", ctx.actor_id, ts, order["id"]))
        ref_no = order["order_no"]
        if action == "scrap":
            holder = None
            db.execute("UPDATE asset_assignments SET released_at=? WHERE asset_id=? AND released_at IS NULL", (ts, a["id"]))
    elif action == "dispose":
        db.execute("UPDATE disposal_orders SET method=? WHERE asset_id=? AND status='APPROVED'", (d.get("method"), a["id"]))
        extra = {"method": d.get("method")}
    elif action == "stock_in":
        db.execute("UPDATE assets SET stock_in_date=? WHERE id=?", (ts[:10], a["id"]))
        loc = _lookup(db, "locations", d.get("location")) or loc

    db.execute("UPDATE assets SET status=?, holder_id=?, department_id=?, location_id=?, updated_at=? WHERE id=?",
               (to_state, holder, dept, loc, ts, a["id"]))
    ev = _event(db, ctx, a["id"], EVENT_NAMES[action], a["status"], to_state, target, dept, loc, ref_no, extra or None)
    audit(db, ctx, action.upper(), "asset", a["id"], old,
          {"status": to_state, "holder_id": holder, "department_id": dept, "location_id": loc, "event_no": ev})
    return {"asset_code": a["asset_code"], "from": a["status"], "to": to_state, "event_no": ev, "ref_no": ref_no}


def asset_timeline(db, asset_id):
    return rows(db.execute("""SELECT e.*, u.full_name actor_name, t.full_name target_name FROM asset_events e
        LEFT JOIN users u ON u.id=e.actor_id LEFT JOIN users t ON t.id=e.target_user_id
        WHERE e.asset_id=? ORDER BY e.id""", (asset_id,)))


def asset_dossier(db, ref):
    a = get_asset(db, ref)
    aid = a["id"]
    a["holder_name"] = (one(db.execute("SELECT full_name FROM users WHERE id=?", (a["holder_id"],))) or {}).get("full_name")
    a["department_name"] = (one(db.execute("SELECT name FROM departments WHERE id=?", (a["department_id"],))) or {}).get("name")
    a["location_name"] = (one(db.execute("SELECT name FROM locations WHERE id=?", (a["location_id"],))) or {}).get("name")
    a["category_name"] = (one(db.execute("SELECT name FROM asset_categories WHERE id=?", (a["category_id"],))) or {}).get("name")
    a["qr_payload"] = f"ITAM://ASSET/{a['uuid']}"
    repairs = rows(db.execute("SELECT * FROM asset_repairs WHERE asset_id=? ORDER BY id", (aid,)))
    a["timeline"] = asset_timeline(db, aid)
    a["repairs"] = repairs
    a["assignments"] = rows(db.execute("""SELECT s.*, u.full_name FROM asset_assignments s JOIN users u ON u.id=s.user_id
        WHERE asset_id=? ORDER BY s.id""", (aid,)))
    a["transfers"] = rows(db.execute("SELECT * FROM asset_transfers WHERE asset_id=? ORDER BY id", (aid,)))
    a["loans"] = rows(db.execute("SELECT * FROM asset_loans WHERE asset_id=? ORDER BY id", (aid,)))
    a["components"] = rows(db.execute("""SELECT s.serial_number, c.name FROM consumable_serials s
        JOIN consumables c ON c.id=s.consumable_id WHERE s.installed_in_asset_id=?""", (aid,)))
    a["repair_cost_total"] = sum(r["cost"] or 0 for r in repairs)
    a["tco"] = (a["purchase_price"] or 0) + a["repair_cost_total"]
    a["health_score"] = health_score(a, repairs)
    return a


def health_score(a, repairs):
    score = 100.0
    if a.get("purchase_date"):
        try:
            years = (datetime.now() - datetime.strptime(a["purchase_date"][:10], "%Y-%m-%d")).days / 365.25
            score -= min(years * 8, 40)
        except ValueError:
            pass
    score -= min(len(repairs) * 6, 30)
    if a.get("purchase_price"):
        score -= min(sum(r["cost"] or 0 for r in repairs) / a["purchase_price"] * 30, 20)
    if a.get("warranty_end") and a["warranty_end"] < now()[:10]:
        score -= 5
    return max(0, round(score))


# ------------------------------------------------------------------ consumable inventory (ledger based)
def create_consumable(db, ctx, d):
    require_role(ctx, STAFF)
    if not d.get("code") or not d.get("name"):
        raise ApiError("code and name are required")
    if db.execute("SELECT 1 FROM consumables WHERE code=?", (d["code"],)).fetchone():
        raise ApiError("consumable code exists", 409, "duplicate")
    cur = db.execute("""INSERT INTO consumables(uuid,code,name,spec,brand,unit,safety_stock,unit_cost,serial_tracked)
        VALUES(?,?,?,?,?,?,?,?,?)""", (str(uuid.uuid4()), d["code"], d["name"], d.get("spec"), d.get("brand"),
                                       d.get("unit", "pcs"), d.get("safety_stock", 0), d.get("unit_cost"),
                                       1 if d.get("serial_tracked") else 0))
    audit(db, ctx, "CREATE", "consumable", cur.lastrowid, None, {"code": d["code"]})
    return cur.lastrowid


def get_consumable(db, ref):
    row = db.execute("SELECT * FROM consumables WHERE id=? OR uuid=? OR code=?",
                     (int(ref) if str(ref).isdigit() else -1, str(ref), str(ref))).fetchone()
    if not row:
        raise ApiError("consumable not found", 404, "not_found")
    return dict(row)


def _txn(db, ctx, cid, bid, ttype, qty, user=None, dept=None, ref_no=None, note=None):
    ts = now()
    n = next_seq(db, "txn:" + ts[:10])
    no = f"TXN-{ts[:10].replace('-', '')}-{n:06d}"
    db.execute("""INSERT INTO inventory_transactions(txn_no,consumable_id,batch_id,txn_type,quantity,to_user_id,
        to_department_id,ref_no,actor_id,note,trace_id,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
               (no, cid, bid, ttype, qty, user, dept, ref_no, ctx.actor_id, note, ctx.trace_id, ts))
    return no


def batch_balance(db, bid):
    return db.execute("SELECT COALESCE(SUM(quantity),0) FROM inventory_transactions WHERE batch_id=?", (bid,)).fetchone()[0]


def receive_stock(db, ctx, d):
    require_role(ctx, STAFF)
    c = get_consumable(db, d.get("consumable"))
    qty = float(d.get("quantity", 0))
    serials = d.get("serials") or []
    if c["serial_tracked"]:
        if not serials:
            raise ApiError("serial-tracked consumable requires 'serials'")
        qty = len(serials)
    if qty <= 0:
        raise ApiError("quantity must be > 0")
    wh = _lookup(db, "warehouses", d.get("warehouse"))
    if not wh:
        raise ApiError("warehouse is required")
    batch_no = d.get("batch_no") or now()[:10].replace("-", "") + "-" + f"{next_seq(db, 'batch:' + c['code']):03d}"
    b = db.execute("SELECT id FROM consumable_batches WHERE consumable_id=? AND batch_no=? AND warehouse_id=?",
                   (c["id"], batch_no, wh)).fetchone()
    bid = b["id"] if b else db.execute("""INSERT INTO consumable_batches(consumable_id,batch_no,warehouse_id,expiry_date,received_at)
        VALUES(?,?,?,?,?)""", (c["id"], batch_no, wh, d.get("expiry_date"), now())).lastrowid
    for sn in serials:
        if db.execute("SELECT 1 FROM consumable_serials WHERE serial_number=?", (sn,)).fetchone():
            raise ApiError(f"duplicate serial {sn}", 409, "duplicate_sn")
        db.execute("INSERT INTO consumable_serials(consumable_id,serial_number,batch_id) VALUES(?,?,?)", (c["id"], sn, bid))
    no = _txn(db, ctx, c["id"], bid, "RECEIPT", qty, ref_no=d.get("ref_no"), note=d.get("note"))
    audit(db, ctx, "STOCK_IN", "consumable", c["id"], None, {"batch_no": batch_no, "qty": qty, "txn_no": no})
    return {"txn_no": no, "batch_id": bid, "batch_no": batch_no, "quantity": qty}


def issue_stock(db, ctx, d):
    """Issue (scan-distribute) consumables. Picks unlocked, non-expired batches FEFO unless a batch is named."""
    require_role(ctx, STAFF)
    c = get_consumable(db, d.get("consumable"))
    user = get_user(db, d.get("user")) if d.get("user") else None
    dept = _lookup(db, "departments", d.get("department")) or (user["department_id"] if user else None)
    if not user and not dept:
        raise ApiError("recipient 'user' or 'department' is required")
    serials = d.get("serials") or []
    qty = float(len(serials) if c["serial_tracked"] else d.get("quantity", 0))
    if c["serial_tracked"] and not serials:
        raise ApiError("serial-tracked consumable requires 'serials'")
    if qty <= 0:
        raise ApiError("quantity must be > 0")
    q = """SELECT b.* FROM consumable_batches b WHERE b.consumable_id=? AND b.locked=0
           AND (b.expiry_date IS NULL OR b.expiry_date>=?)"""
    args = [c["id"], now()[:10]]
    if d.get("batch_no"):
        q += " AND b.batch_no=?"
        args.append(d["batch_no"])
    q += " ORDER BY b.expiry_date IS NULL, b.expiry_date, b.received_at, b.id"
    remaining, out = qty, []
    for b in db.execute(q, args).fetchall():
        bal = batch_balance(db, b["id"])
        take = min(bal, remaining)
        if take > 0:
            no = _txn(db, ctx, c["id"], b["id"], "ISSUE", -take, user["id"] if user else None, dept, d.get("ref_no"), d.get("note"))
            out.append({"txn_no": no, "batch_no": b["batch_no"], "quantity": take})
            remaining -= take
        if remaining <= 0:
            break
    if remaining > 0:
        raise ApiError(f"insufficient available stock: short by {remaining:g} (locked/expired batches are excluded)",
                       409, "insufficient_stock")
    for sn in serials:
        s = one(db.execute("SELECT * FROM consumable_serials WHERE serial_number=? AND consumable_id=?", (sn, c["id"])))
        if not s or s["status"] != "IN_STOCK":
            raise ApiError(f"serial {sn} is not in stock", 409, "serial_unavailable")
        db.execute("UPDATE consumable_serials SET status='ISSUED' WHERE id=?", (s["id"],))
    audit(db, ctx, "ISSUE_CONSUMABLE", "consumable", c["id"], None,
          {"qty": qty, "to_user": user["id"] if user else None, "dept": dept, "lines": out})
    return {"quantity": qty, "lines": out}


def return_stock(db, ctx, d):
    require_role(ctx, STAFF)
    c = get_consumable(db, d.get("consumable"))
    b = db.execute("SELECT * FROM consumable_batches WHERE consumable_id=? AND batch_no=?", (c["id"], d.get("batch_no"))).fetchone()
    if not b:
        raise ApiError("batch_no required and must exist", 404, "not_found")
    qty = float(d.get("quantity", 0))
    if qty <= 0:
        raise ApiError("quantity must be > 0")
    user = get_user(db, d.get("user")) if d.get("user") else None
    no = _txn(db, ctx, c["id"], b["id"], "RETURN", qty, user["id"] if user else None, ref_no=d.get("ref_no"))
    audit(db, ctx, "RETURN_CONSUMABLE", "consumable", c["id"], None, {"qty": qty, "txn_no": no})
    return {"txn_no": no}


def scrap_stock(db, ctx, d):
    require_role(ctx, STAFF)
    c = get_consumable(db, d.get("consumable"))
    b = db.execute("SELECT * FROM consumable_batches WHERE consumable_id=? AND batch_no=?", (c["id"], d.get("batch_no"))).fetchone()
    if not b:
        raise ApiError("batch_no required and must exist", 404, "not_found")
    qty = float(d.get("quantity", 0))
    if qty <= 0 or qty > batch_balance(db, b["id"]):
        raise ApiError("invalid quantity for scrap", 409, "insufficient_stock")
    no = _txn(db, ctx, c["id"], b["id"], "SCRAP", -qty, note=d.get("reason"))
    audit(db, ctx, "SCRAP_CONSUMABLE", "consumable", c["id"], None, {"qty": qty, "txn_no": no})
    return {"txn_no": no}


def adjust_stock(db, ctx, d):
    """Stocktake correction: set a batch to the counted quantity; writes a +/- ADJUST ledger line."""
    require_role(ctx, ADMINS | {"WAREHOUSE_ADMIN"})
    c = get_consumable(db, d.get("consumable"))
    b = db.execute("SELECT * FROM consumable_batches WHERE consumable_id=? AND batch_no=?", (c["id"], d.get("batch_no"))).fetchone()
    if not b:
        raise ApiError("batch not found", 404, "not_found")
    counted = float(d.get("counted_quantity"))
    delta = counted - batch_balance(db, b["id"])
    if delta == 0:
        return {"delta": 0}
    no = _txn(db, ctx, c["id"], b["id"], "ADJUST_GAIN" if delta > 0 else "ADJUST_LOSS", delta, note=d.get("reason"))
    audit(db, ctx, "STOCKTAKE_ADJUST", "consumable", c["id"], None, {"delta": delta, "txn_no": no})
    return {"delta": delta, "txn_no": no}


def lock_batch(db, ctx, consumable, batch_no, locked, reason=None):
    require_role(ctx, ADMINS | {"WAREHOUSE_ADMIN"})
    c = get_consumable(db, consumable)
    cur = db.execute("UPDATE consumable_batches SET locked=?, lock_reason=? WHERE consumable_id=? AND batch_no=?",
                     (1 if locked else 0, reason if locked else None, c["id"], batch_no))
    if cur.rowcount == 0:
        raise ApiError("batch not found", 404, "not_found")
    audit(db, ctx, "LOCK_BATCH" if locked else "UNLOCK_BATCH", "consumable", c["id"], None, {"batch_no": batch_no, "reason": reason})


def stock_summary(db, consumable=None):
    q = "SELECT * FROM consumables WHERE active=1"
    args = ()
    if consumable:
        q, args = "SELECT * FROM consumables WHERE id=?", (get_consumable(db, consumable)["id"],)
    out = []
    for c in rows(db.execute(q, args)):
        batches = rows(db.execute("""SELECT b.id, b.batch_no, b.expiry_date, b.locked, b.lock_reason, w.name warehouse,
            COALESCE((SELECT SUM(quantity) FROM inventory_transactions t WHERE t.batch_id=b.id),0) on_hand
            FROM consumable_batches b JOIN warehouses w ON w.id=b.warehouse_id WHERE b.consumable_id=?""", (c["id"],)))
        total = sum(b["on_hand"] for b in batches)
        today = now()[:10]
        avail = sum(b["on_hand"] for b in batches if not b["locked"] and not (b["expiry_date"] and b["expiry_date"] < today))
        c.update(batches=batches, on_hand=total, available=avail, low_stock=avail < c["safety_stock"])
        out.append(c)
    return out


def trace_batch(db, consumable, batch_no):
    c = get_consumable(db, consumable)
    b = one(db.execute("SELECT * FROM consumable_batches WHERE consumable_id=? AND batch_no=?", (c["id"], batch_no)))
    if not b:
        raise ApiError("batch not found", 404, "not_found")
    ledger = rows(db.execute("""SELECT t.*, u.full_name to_user, d.name to_department FROM inventory_transactions t
        LEFT JOIN users u ON u.id=t.to_user_id LEFT JOIN departments d ON d.id=t.to_department_id
        WHERE t.batch_id=? ORDER BY t.id""", (b["id"],)))
    recipients = rows(db.execute("""SELECT u.full_name user, d.name department, -SUM(t.quantity) quantity
        FROM inventory_transactions t LEFT JOIN users u ON u.id=t.to_user_id LEFT JOIN departments d ON d.id=t.to_department_id
        WHERE t.batch_id=? AND t.txn_type='ISSUE' GROUP BY t.to_user_id, t.to_department_id""", (b["id"],)))
    return {"consumable": c["name"], "batch": b, "on_hand": batch_balance(db, b["id"]), "ledger": ledger, "issued_to": recipients}


def reconcile_inventory(db):
    """Ledger integrity: no batch may be negative; returns per-batch balances."""
    bad = rows(db.execute("""SELECT batch_id, SUM(quantity) bal FROM inventory_transactions GROUP BY batch_id HAVING bal < 0"""))
    return {"ok": not bad, "negative_batches": bad}


def serial_install(db, ctx, serial, asset_ref, remove=False):
    require_role(ctx, STAFF)
    s = one(db.execute("SELECT * FROM consumable_serials WHERE serial_number=?", (serial,)))
    if not s:
        raise ApiError("serial not found", 404, "not_found")
    a = get_asset(db, asset_ref)
    if remove:
        if s["installed_in_asset_id"] != a["id"]:
            raise ApiError("serial is not installed in this asset", 409, "invalid_state")
        db.execute("UPDATE consumable_serials SET installed_in_asset_id=NULL, status='IN_STOCK' WHERE id=?", (s["id"],))
        _event(db, ctx, a["id"], "COMPONENT_REMOVED", a["status"], a["status"], payload={"serial": serial})
    else:
        if s["status"] not in ("ISSUED", "IN_STOCK"):
            raise ApiError("serial not available", 409, "invalid_state")
        db.execute("UPDATE consumable_serials SET installed_in_asset_id=?, status='INSTALLED' WHERE id=?", (a["id"], s["id"]))
        _event(db, ctx, a["id"], "COMPONENT_INSTALLED", a["status"], a["status"], payload={"serial": serial})
    audit(db, ctx, "COMPONENT_REMOVE" if remove else "COMPONENT_INSTALL", "asset", a["id"], None, {"serial": serial})


# ------------------------------------------------------------------ repair integration
def repair_payload(db, r):
    a = get_asset(db, r["asset_id"])
    reporter = one(db.execute("SELECT emp_no FROM users WHERE id=?", (r["reported_by"],))) or {}
    return {"assetId": a["uuid"], "assetCode": a["asset_code"], "serialNumber": a["serial_number"],
            "reportedBy": reporter.get("emp_no"), "faultDescription": r["fault"], "localRepairNo": r["local_no"]}


def mark_synced(db, repair_id, remote_id):
    db.execute("UPDATE asset_repairs SET remote_repair_id=?, sync_status='SYNCED' WHERE id=?", (remote_id, repair_id))


def log_integration(db, direction, endpoint, request, response, ok, trace_id):
    db.execute("INSERT INTO integration_logs(direction,endpoint,request,response,ok,trace_id,created_at) VALUES(?,?,?,?,?,?,?)",
               (direction, endpoint, _canon(request), str(response)[:4000], 1 if ok else 0, trace_id, now()))


def handle_repair_webhook(db, ctx, body):
    """Idempotent inbound repair event. Must be called inside tx(); a failure rolls back the dedupe record too."""
    event_id = body.get("eventId") or hashlib.sha256(_canon(body).encode()).hexdigest()
    if db.execute("SELECT 1 FROM webhook_events WHERE event_id=?", (event_id,)).fetchone():
        return {"status": "duplicate_ignored", "eventId": event_id}
    etype = body.get("event")
    if etype not in ("REPAIR_STARTED", "REPAIR_COMPLETED", "REPAIR_CANCELLED"):
        raise ApiError(f"unsupported event '{etype}'", 400, "unsupported_event")
    r = None
    if body.get("repairId"):
        r = one(db.execute("SELECT * FROM asset_repairs WHERE remote_repair_id=?", (body["repairId"],)))
    if not r and body.get("localRepairNo"):
        r = one(db.execute("SELECT * FROM asset_repairs WHERE local_no=?", (body["localRepairNo"],)))
    if not r and body.get("assetId"):
        a = get_asset(db, body["assetId"])
        r = one(db.execute("SELECT * FROM asset_repairs WHERE asset_id=? AND status IN ('OPEN','IN_PROGRESS') ORDER BY id DESC", (a["id"],)))
    if not r:
        raise ApiError("no matching repair order", 404, "not_found")
    if body.get("repairId") and not r["remote_repair_id"]:
        db.execute("UPDATE asset_repairs SET remote_repair_id=?, sync_status='SYNCED' WHERE id=?", (body["repairId"], r["id"]))
    result = {"repair": r["local_no"], "event": etype}
    if etype == "REPAIR_STARTED":
        if r["status"] == "OPEN":
            db.execute("UPDATE asset_repairs SET status='IN_PROGRESS' WHERE id=?", (r["id"],))
    elif r["status"] in ("COMPLETED", "CANCELLED"):
        result["note"] = "repair already closed"
    else:
        done = etype == "REPAIR_COMPLETED"
        db.execute("UPDATE asset_repairs SET status=?, result=?, cost=?, completed_at=? WHERE id=?",
                   ("COMPLETED" if done else "CANCELLED", body.get("result"), body.get("cost"),
                    (body.get("completedAt") or now()).replace("T", " ")[:19], r["id"]))
        sys_ctx = Ctx(actor_name="system:repair", role="SYSTEM", trace_id=ctx.trace_id, ip=ctx.ip)
        asset = get_asset(db, r["asset_id"])
        if asset["status"] == "REPAIR":
            if done:
                result["asset"] = apply_action(db, sys_ctx, asset["id"], "repair_complete",
                                               {"result": body.get("result"), "cost": body.get("cost"), "ref_no": r["local_no"]})
            else:  # cancelled: back to stock/in-use state it came from is a manual decision -> READY_FOR_USE
                result["asset"] = apply_action(db, sys_ctx, asset["id"], "repair_complete",
                                               {"result": "CANCELLED", "ref_no": r["local_no"]})
    db.execute("INSERT INTO webhook_events(event_id,event_type,body,result,received_at) VALUES(?,?,?,?,?)",
               (event_id, etype, _canon(body), _canon(result), now()))
    audit(db, ctx, "WEBHOOK_" + etype, "repair", r["id"], None, result)
    return {"status": "processed", "eventId": event_id, **result}


# ------------------------------------------------------------------ stocktake (assets)
def create_check(db, ctx, location):
    require_role(ctx, STAFF)
    loc = _lookup(db, "locations", location)
    if not loc:
        raise ApiError("location required")
    n = next_seq(db, "check:" + now()[:4])
    no = f"CHK-{now()[:4]}-{n:04d}"
    cid = db.execute("INSERT INTO inventory_checks(check_no,location_id,status,created_by,created_at) VALUES(?,?,'OPEN',?,?)",
                     (no, loc, ctx.actor_id, now())).lastrowid
    db.execute("""INSERT INTO inventory_check_items(check_id,asset_id,expected_location_id)
        SELECT ?, id, location_id FROM assets WHERE location_id=? AND status NOT IN ('SCRAPPED','DISPOSED','DRAFT')""", (cid, loc))
    audit(db, ctx, "INVENTORY_CHECK_OPEN", "inventory_check", cid, None, {"check_no": no})
    return {"id": cid, "check_no": no, **check_summary(db, cid)}


def scan_check(db, ctx, check_id, code):
    require_role(ctx, STAFF)
    chk = one(db.execute("SELECT * FROM inventory_checks WHERE id=? OR check_no=?", (int(check_id) if str(check_id).isdigit() else -1, str(check_id))))
    if not chk or chk["status"] != "OPEN":
        raise ApiError("open inventory check not found", 404, "not_found")
    a = get_asset(db, code)
    item = one(db.execute("SELECT * FROM inventory_check_items WHERE check_id=? AND asset_id=?", (chk["id"], a["id"])))
    ts = now()
    if item:
        result = "OK"
        db.execute("UPDATE inventory_check_items SET scanned=1, actual_location_id=?, result=?, scanned_at=? WHERE id=?",
                   (chk["location_id"], result, ts, item["id"]))
    else:
        result = "LOCATION_MISMATCH"   # asset booked elsewhere but found here
        db.execute("""INSERT INTO inventory_check_items(check_id,asset_id,expected_location_id,scanned,actual_location_id,result,scanned_at)
            VALUES(?,?,?,?,?,?,?)""", (chk["id"], a["id"], a["location_id"], 1, chk["location_id"], result, ts))
    _event(db, ctx, a["id"], "INVENTORY_SCANNED", a["status"], a["status"], loc=chk["location_id"], ref_no=chk["check_no"], payload={"result": result})
    return {"asset_code": a["asset_code"], "result": result}


def check_summary(db, check_id):
    items = rows(db.execute("SELECT * FROM inventory_check_items WHERE check_id=?", (check_id,)))
    return {"expected": sum(1 for i in items if i["expected_location_id"] and i["result"] != "LOCATION_MISMATCH"),
            "scanned": sum(1 for i in items if i["scanned"]),
            "unscanned": sum(1 for i in items if not i["scanned"]),
            "exceptions": sum(1 for i in items if i["result"] in ("LOCATION_MISMATCH", "MISSING"))}


def close_check(db, ctx, check_id):
    require_role(ctx, STAFF)
    chk = one(db.execute("SELECT * FROM inventory_checks WHERE id=? OR check_no=?", (int(check_id) if str(check_id).isdigit() else -1, str(check_id))))
    if not chk or chk["status"] != "OPEN":
        raise ApiError("open inventory check not found", 404, "not_found")
    db.execute("UPDATE inventory_check_items SET result='MISSING' WHERE check_id=? AND scanned=0", (chk["id"],))
    db.execute("UPDATE inventory_checks SET status='CLOSED', closed_at=? WHERE id=?", (now(), chk["id"]))
    audit(db, ctx, "INVENTORY_CHECK_CLOSE", "inventory_check", chk["id"], None, check_summary(db, chk["id"]))
    return check_summary(db, chk["id"])


# ------------------------------------------------------------------ anomalies & reports
def anomalies(db):
    out, today = [], now()[:10]
    for r in db.execute("""SELECT a.asset_code, l.due_date, u.full_name FROM asset_loans l JOIN assets a ON a.id=l.asset_id
            JOIN users u ON u.id=l.borrower_id WHERE l.returned_at IS NULL AND l.due_date IS NOT NULL AND l.due_date<?""", (today,)):
        out.append({"kind": "LOAN_OVERDUE", "ref": r["asset_code"], "message": f"{r['asset_code']} loan to {r['full_name']} overdue since {r['due_date']}"})
    limit = (datetime.now() - timedelta(hours=48)).strftime("%Y-%m-%d %H:%M:%S")
    for r in db.execute("""SELECT a.asset_code, p.local_no FROM asset_repairs p JOIN assets a ON a.id=p.asset_id
            WHERE p.status IN ('OPEN','IN_PROGRESS') AND p.opened_at<?""", (limit,)):
        out.append({"kind": "REPAIR_OVERDUE", "ref": r["local_no"], "message": f"{r['asset_code']} repair {r['local_no']} open > 48h"})
    for r in db.execute("""SELECT local_no, asset_id FROM asset_repairs WHERE sync_status IN ('PENDING','FAILED') AND status='OPEN'"""):
        out.append({"kind": "REPAIR_SYNC_PENDING", "ref": r["local_no"], "message": f"repair {r['local_no']} not yet synced to repair system"})
    soon = (datetime.now() + timedelta(days=30)).strftime("%Y-%m-%d")
    for r in db.execute("""SELECT asset_code, warranty_end FROM assets WHERE warranty_end IS NOT NULL AND warranty_end BETWEEN ? AND ?
            AND status NOT IN ('SCRAPPED','DISPOSED')""", (today, soon)):
        out.append({"kind": "WARRANTY_EXPIRING", "ref": r["asset_code"], "message": f"{r['asset_code']} warranty ends {r['warranty_end']}"})
    idle = (datetime.now() - timedelta(days=180)).strftime("%Y-%m-%d")
    for r in db.execute("SELECT asset_code FROM assets WHERE status='IN_STOCK' AND stock_in_date IS NOT NULL AND stock_in_date<?", (idle,)):
        out.append({"kind": "LONG_IDLE", "ref": r["asset_code"], "message": f"{r['asset_code']} idle in stock > 180 days"})
    for s in stock_summary(db):
        if s["low_stock"]:
            out.append({"kind": "LOW_STOCK", "ref": s["code"], "message": f"{s['name']} available {s['available']:g} < safety {s['safety_stock']:g}"})
        for b in s["batches"]:
            if b["expiry_date"] and b["expiry_date"] < today and b["on_hand"] > 0:
                out.append({"kind": "BATCH_EXPIRED", "ref": f"{s['code']}/{b['batch_no']}", "message": f"{s['name']} batch {b['batch_no']} expired with {b['on_hand']:g} left"})
    for r in db.execute("""SELECT a.asset_code, c.check_no FROM inventory_check_items i JOIN assets a ON a.id=i.asset_id
            JOIN inventory_checks c ON c.id=i.check_id WHERE i.result IN ('LOCATION_MISMATCH','MISSING')"""):
        out.append({"kind": "CHECK_EXCEPTION", "ref": f"{r['check_no']}/{r['asset_code']}", "message": f"{r['asset_code']} exception in {r['check_no']}"})
    return out


def publish_notifications(db):
    n = 0
    for a in anomalies(db):
        n += db.execute("INSERT OR IGNORE INTO notifications(kind,message,ref,created_at) VALUES(?,?,?,?)",
                        (a["kind"], a["message"], a["ref"], now())).rowcount
    return n


def reports_overview(db):
    by_status = rows(db.execute("SELECT status, COUNT(*) n FROM assets GROUP BY status"))
    by_dept = rows(db.execute("""SELECT COALESCE(d.name,'(未分配)') department, COUNT(*) n FROM assets a
        LEFT JOIN departments d ON d.id=a.department_id WHERE a.status NOT IN ('SCRAPPED','DISPOSED') GROUP BY 1 ORDER BY n DESC"""))
    by_cat = rows(db.execute("""SELECT c.name category, COUNT(*) n, COALESCE(SUM(a.purchase_price),0) value FROM assets a
        JOIN asset_categories c ON c.id=a.category_id GROUP BY c.id ORDER BY n DESC"""))
    rep = one(db.execute("""SELECT COUNT(*) n, COALESCE(SUM(cost),0) cost FROM asset_repairs""")) or {}
    top = rows(db.execute("""SELECT a.asset_code, a.name, COUNT(*) repairs, COALESCE(SUM(p.cost),0) cost FROM asset_repairs p
        JOIN assets a ON a.id=p.asset_id GROUP BY a.id ORDER BY repairs DESC, cost DESC LIMIT 10"""))
    avg = db.execute("""SELECT AVG((julianday(completed_at)-julianday(opened_at))*24) FROM asset_repairs WHERE completed_at IS NOT NULL""").fetchone()[0]
    total_value = db.execute("SELECT COALESCE(SUM(purchase_price),0) FROM assets WHERE status NOT IN ('SCRAPPED','DISPOSED')").fetchone()[0]
    return {"total_assets": sum(s["n"] for s in by_status), "asset_value": total_value, "by_status": by_status,
            "by_department": by_dept, "by_category": by_cat,
            "repairs": {"count": rep.get("n", 0), "cost": rep.get("cost", 0), "avg_hours": round(avg, 1) if avg else None, "top_assets": top},
            "low_stock": [s["name"] for s in stock_summary(db) if s["low_stock"]]}


# ------------------------------------------------------------------ scan resolver
def resolve_scan(db, code):
    code = (code or "").strip()
    if not code:
        raise ApiError("empty scan")
    if code.startswith("ITAM://"):
        _, _, rest = code.partition("ITAM://")
        kind, _, ident = rest.partition("/")
        kind = kind.upper()
        table = {"ASSET": "assets", "CONSUMABLE": "consumables", "LOCATION": "locations", "WAREHOUSE": "warehouses", "USER": "users"}.get(kind)
        if not table:
            raise ApiError(f"unknown code type {kind}")
        row = one(db.execute(f"SELECT * FROM {table} WHERE uuid=?", (ident,)))
        if not row:
            raise ApiError("code not recognised", 404, "not_found")
        row.pop("password_hash", None)
        return {"type": kind.lower(), "data": asset_dossier(db, row["id"]) if kind == "ASSET" else row}
    for kind, sql in (("asset", "SELECT id FROM assets WHERE asset_code=? OR serial_number=?"),
                      ("user", "SELECT id FROM users WHERE emp_no=? OR username=?"),
                      ("consumable", "SELECT id FROM consumables WHERE code=? OR code=?")):
        r = db.execute(sql, (code, code)).fetchone()
        if r:
            if kind == "asset":
                return {"type": "asset", "data": asset_dossier(db, r["id"])}
            if kind == "user":
                u = get_user(db, r["id"])
                u.pop("password_hash", None)
                u["assets"] = rows(db.execute("SELECT asset_code,name,status FROM assets WHERE holder_id=?", (u["id"],)))
                return {"type": "user", "data": u}
            return {"type": "consumable", "data": stock_summary(db, r["id"])[0]}
    raise ApiError("code not recognised", 404, "not_found")
