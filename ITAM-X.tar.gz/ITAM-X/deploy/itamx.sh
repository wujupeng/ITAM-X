#!/usr/bin/env bash
# Run on the server, inside the project dir:  ./deploy/itamx.sh start|stop|restart|status|logs
# No root needed. Reads ./.env (ITAMX_* variables).
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p run data
PID=run/itamx.pid
[ -f .env ] && set -a && . ./.env && set +a
export ITAMX_DB="${ITAMX_DB:-$PWD/data/itamx.db}"
PORT="${ITAMX_PORT:-8080}"

running() { [ -f "$PID" ] && kill -0 "$(cat "$PID")" 2>/dev/null; }
case "${1:-status}" in
  start)
    running && { echo "already running (pid $(cat $PID))"; exit 0; }
    # SQLite => exactly one worker process; threads handle concurrency.
    nohup .venv/bin/gunicorn -w 1 --threads 8 -b "0.0.0.0:$PORT" --pid "$PID" \
      --access-logfile run/access.log --error-logfile run/error.log run:app >/dev/null 2>&1 &
    for i in 1 2 3 4 5 6 7 8 9 10; do sleep 1; curl -fs "http://127.0.0.1:$PORT/api/v1/health" >/dev/null && { echo "started on :$PORT"; exit 0; }; done
    echo "failed to start, see run/error.log"; tail -20 run/error.log; exit 1 ;;
  stop)    running && kill "$(cat $PID)" && echo stopped || echo "not running" ;;
  restart) "$0" stop; sleep 1; "$0" start ;;
  status)  running && echo "running (pid $(cat $PID))" && curl -s "http://127.0.0.1:$PORT/api/v1/health" && echo || echo "not running" ;;
  logs)    tail -n 100 -f run/error.log ;;
  *) echo "usage: $0 start|stop|restart|status|logs"; exit 2 ;;
esac
