#!/usr/bin/env bash
# Deploy from the dev machine to the server over passwordless SSH.
#   ./deploy/deploy.sh                # defaults: debian@192.168.2.3:/home/debian/ITAM-X
#   HOST=… USER_=… DEST=… ./deploy/deploy.sh
set -euo pipefail
HOST="${HOST:-192.168.2.3}"; USER_="${USER_:-debian}"; DEST="${DEST:-/home/$USER_/ITAM-X}"
SSH="ssh -o BatchMode=yes -o ConnectTimeout=8 $USER_@$HOST"
cd "$(dirname "$0")/.."

echo "==> checking SSH to $USER_@$HOST"
$SSH 'echo connected as $(whoami) on $(hostname); python3 --version' 
$SSH 'python3 -c "import venv, ensurepip" 2>/dev/null' || { echo "ERROR: python3-venv missing on server. Run once:  sudo apt-get install -y python3-venv"; exit 1; }

echo "==> syncing code to $DEST"
$SSH "mkdir -p '$DEST'"
if command -v rsync >/dev/null && $SSH 'command -v rsync >/dev/null'; then
  rsync -az --delete --exclude .git --exclude data --exclude run --exclude .venv --exclude .env \
        --exclude __pycache__ --exclude .pytest_cache -e "ssh -o BatchMode=yes" ./ "$USER_@$HOST:$DEST/"
else
  tar --exclude=.git --exclude=data --exclude=run --exclude=.venv --exclude=.env --exclude=__pycache__ -czf - . \
    | $SSH "cd '$DEST' && tar -xzf -"
fi

echo "==> installing dependencies"
$SSH "cd '$DEST' && python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt"

echo "==> first-time config (.env)"
$SSH "cd '$DEST' && [ -f .env ] || { umask 077; printf 'ITAMX_PORT=8080\nITAMX_WEBHOOK_SECRET=%s\n# ITAMX_ADMIN_PASSWORD=\n# ITAMX_REPAIR_URL=http://repair-system:PORT\n# ITAMX_REPAIR_TOKEN=\n' \"\$(head -c 24 /dev/urandom | base64 | tr -d '/+=')\" > .env; echo created .env; }"

echo "==> (re)starting"
$SSH "cd '$DEST' && chmod +x deploy/itamx.sh && ./deploy/itamx.sh restart"
echo "==> done:  http://$HOST:8080/"
echo "    initial admin password (first deploy only):  $SSH 'cat $DEST/data/admin_password.txt'"
